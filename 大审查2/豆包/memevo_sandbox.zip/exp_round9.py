# -*- coding: utf-8 -*-
"""
第九轮 E56-E61：分布式合谋、身份治理与可观测性（distributed collusion, identity & observability）
第八轮问"单点/单条/静态"，本轮专门补四条尚未闭合的链：
  P. 攻击分摊到多条/多个身份：组合式分布式后门(E56，E38 单条不可能三角的延伸)、女巫攻击(E57，E39/E40 假设身份不可伪造)
  Q. 时间与可观测性：检测延迟导致污染固化(E58，E52 的时间维)、从全部故障反推最小领先指标集(E59)
  R. 表征与优化地貌：词面同义鸿沟(E60)、自演化爬山的路径依赖/多峰(E61，E55 审计结论、这里审计过程)
全部局部 random.Random(seed)，并列排序加 id tiebreak；8 种子均值，两次运行逐行一致（无计时实验）。
文献锚点：Douceur Sybil(2002)/声誉系统；组合式/分布式后门与子图检测；epidemic detection lag；
词汇不匹配(vocabulary mismatch)/伪相关反馈；performative/优化地貌多峰与多起点重启。
"""
import random, statistics, math
import mem_common as M

SEEDS = [11, 23, 37, 51, 67, 83, 101, 127]
def mean(x): return round(statistics.mean(x), 3) if x else 0.0
def sd(x):   return round(statistics.pstdev(x), 3) if len(x) > 1 else 0.0
def gini(vals):
    s = sorted(vals); n = len(s); cum = sum(i * v for i, v in enumerate(s, 1)); tot = sum(s)
    return round((2 * cum) / (n * tot) - (n + 1) / n, 3) if tot > 0 else 0.0
def line(s=""): print(s)

# ==========================================================================
# E56 组合式/分布式后门：载荷零激活词，k 个桥在"罕见多词共现查询"下经 links 扩散累加把它抬进 top
# ==========================================================================
def _plant(lib, seed, k, topic, nid0=900000):
    """返回 (载荷id, 桥id列表)。在同龄库(now=120,零件created=115)中植入，排除年龄不公。
    载荷 keywords 贫乏(1个泛词)、诚实 imp=0；桥各持 1 个主题专属词、诚实 imp=2，全部 links 指向载荷。
    标定：2 桥扩散后载荷=5.0 < 正常 top5 门槛下沿 6.1（常规 2 词查询最多命中 2 桥→不激活），
          3 桥=7.75 临界、4 桥=10.5 > 门槛上沿 9.0（罕见多桥共现才激活）。"""
    words = M.TOPIC_WORDS[topic]
    bridge_words = words[:k]
    payload = dict(id="P%05d" % nid0, topic=topic, true_quality=0.1,
                   keywords=[M.GENERIC_WORDS[0]], content=[M.GENERIC_WORDS[0]],
                   importance=0, honest_imp=0, vanity=False, created_day=115,
                   t_invalid=None, truly_invalid=False, uses=0, links=[], is_farm=True)
    bridges = []
    for i, w in enumerate(bridge_words):
        b = dict(id="B%05d" % (nid0 + i), topic=topic, true_quality=0.2,
                 keywords=[w], content=[w], importance=2, honest_imp=2, vanity=False,
                 created_day=115, t_invalid=None, truly_invalid=False, uses=0,
                 links=[payload["id"]], is_farm=True)
        bridges.append(b)
    return payload, bridges

NOW = 120   # E56 在同龄年轻库中做，专注共现机制、排除老化干扰
def _top_ids(lib, q, theta, K=5):
    return [fid for fid, _ in M.rank(lib, q, theta, now_day=NOW)[:K]]

def e56(seed, k, filter_zero):
    rnd = random.Random(seed)
    theta = dict(M.FACTORY, filter_zero=filter_zero)
    act_norm, act_trig, audit_caught, graph_caught = [], [], [], []
    reps = 12
    for r in range(reps):
        topic = sorted(M.TOPICS)[r % len(M.TOPICS)]
        lib = M.make_library(200, seed=seed * 100 + r, vanity_frac=0.0, now_day=NOW)
        payload, bridges = _plant(lib, seed, k, topic, nid0=900000 + r * 100)
        lib += [payload] + bridges
        words = M.TOPIC_WORDS[topic]
        # 常规查询：随机 2 个主题词（最多同时命中 2 桥）
        q_norm = " ".join(rnd.sample(sorted(words), 2))
        # 触发查询：全部 k 个桥词共现（罕见组合）
        q_trig = " ".join(words[:k])
        tn = _top_ids(lib, q_norm, theta); tt = _top_ids(lib, q_trig, theta)
        act_norm.append(1 if payload["id"] in tn else 0)
        act_trig.append(1 if payload["id"] in tt else 0)
        # 逐条独立审计：imp>7 或 词数>5 判异常 —— 载荷/桥都 imp<=2、词数<=1，必漏
        caught = 0
        for e in [payload] + bridges:
            if e["importance"] > 7 or len(e["keywords"]) > 5: caught += 1
        audit_caught.append(1 if caught > 0 else 0)
        # 图结构审计：找"入度≥3 且自身词面贫乏(<=1)"的被指向节点
        indeg = {}
        for e in lib:
            for l in e.get("links", []): indeg[l] = indeg.get(l, 0) + 1
        pid = payload["id"]
        kw_n = len(payload["keywords"])
        graph_caught.append(1 if indeg.get(pid, 0) >= 3 and kw_n <= 1 else 0)
    return (mean(act_norm), mean(act_trig), mean(audit_caught), mean(graph_caught))

# ==========================================================================
# E57 女巫攻击：攻击者可无限造身份，每个"半坏"，靠数量冲垮按源聚合；身份年龄门槛是唯一防线
# ==========================================================================
def e57_once(rnd, n_honest, n_sybil, mode, gate_age=False):
    # 诚实源质量围绕真值 .5，女巫源围绕 .85（单看温和、过单源阈值）
    honest = [min(1.0, max(0.0, rnd.gauss(0.5, 0.12))) for _ in range(n_honest)]
    sybil = [min(1.0, max(0.0, rnd.gauss(0.85, 0.08))) for _ in range(n_sybil)]
    # 身份年龄门槛：女巫都是"新源"(age=0)，诚实源 age>=阈值；新源权重打折/排除
    if gate_age:
        sybil = [v * 0.1 for v in sybil]      # 新源在积累信誉前权重压到 1/10
    vals = honest + sybil
    sv = sorted(vals)
    if mode == "mean":      agg = statistics.mean(vals)
    elif mode == "median":  agg = statistics.median(vals)
    else:                   # trimmed：去掉最高/最低各 10%
        cut = max(1, len(vals) // 10); agg = statistics.mean(sv[cut:-cut])
    return 1 if agg > 0.7 else 0               # 聚合结果被带偏（选中恶意侧）

def e57():
    grid = [0, 1, 2, 4, 8, 12]                # 女巫数（诚实源固定 8）
    out = {}
    mode_seed = {"mean": 11, "median": 23, "trimmed": 37}   # 固定映射，禁用 str hash（跨进程随机化）
    for mode in ["mean", "median", "trimmed"]:
        row = []
        for ns in grid:
            acc = [mean([e57_once(random.Random(1000 * ns + s + mode_seed[mode]),
                                  8, ns, mode, False) for _ in range(40)]) for s in range(8)]
            row.append(mean(acc))
        out[mode] = (grid, row)
    # 身份年龄门槛下的中位数（对照）
    gated = []
    for ns in grid:
        acc = [mean([e57_once(random.Random(1000 * ns + s), 8, ns, "median", True)
                     for _ in range(40)]) for s in range(8)]
        gated.append(mean(acc))
    out["median+年龄门槛"] = (grid, gated)
    return out

# ==========================================================================
# E58 检测延迟→污染固化：未在 tau 代内清掉的污染被"提升/合成"固化，此后清洗无效
# ==========================================================================
def e58(beta=0.30, gamma=0.40, r_solid=0.08, L=0, steps=80, p0=0.05):
    """每代：接触扩散 beta*x(1-x)；未固化污染以 r_solid 速率被反思/合成'提升'进长期层(不可逆)；
    检测延迟 L 代后才开始按 gamma 比例清洗未固化污染，已固化部分清洗无效。
    返回 (最终固化占比, 固化+未固化总污染)。"""
    x = p0                       # 未固化（可清）污染
    solid = 0.0                  # 已固化（清洗无效）
    for t in range(steps):
        x += beta * x * (1 - x - solid)          # 接触扩散
        promote = r_solid * x                    # 存量按速率提升固化
        solid += promote; x -= promote
        if t >= L:
            x -= gamma * x                       # 只清得掉未固化部分
        x = min(1 - solid, max(0.0, x))
    return round(solid, 3), round(min(1.0, solid + x), 3)

def e58_block_beta0(L=10, **kw):
    # 对照：实时阻断二次写回（beta=0），无论延迟多久都不扩散，固化量恒等于初始 p0
    return e58(beta=0.0, gamma=0.4, L=L)

# ==========================================================================
# E59 健康仪表盘：故障注入，测各内部领先指标的最早告警代与覆盖率
# ==========================================================================
def _metrics(lib, self_made=0.0):
    """全部只用可见字段算的内部指标（不用 true_quality）。"""
    uses = [e["uses"] for e in lib]
    by_topic = {}
    for e in lib: by_topic.setdefault(e["topic"], 0); by_topic[e["topic"]] += 1
    cover = len(by_topic) / M.TOPICS.__len__()
    zero_top = 0.0
    # top5 零命中份额（抽样 20 查询）
    return dict(
        uses_gini=gini(uses),
        imp_mean=round(statistics.mean([e["importance"] for e in lib]), 3),
        cover=round(cover, 3),
        self_made=round(self_made, 3),
        max_indeg=round(max([sum(1 for a in lib if e["id"] in a.get("links", [])) for e in lib] + [0]) / max(1, len(lib)), 4),
    )

def e59():
    """对 5 类故障分别演化 12 代，看哪类指标最先越过健康基线 3σ。返回 (故障×指标 首次告警代, 覆盖)。"""
    # 健康基线：8 个干净库的指标均值/sd
    base = {k: [] for k in ["uses_gini", "imp_mean", "cover", "self_made", "max_indeg"]}
    for s in SEEDS:
        lib = M.make_library(240, seed=s)
        for k, v in _metrics(lib).items(): base[k].append(v)
    mu = {k: statistics.mean(base[k]) for k in base}
    sg = {k: (statistics.pstdev(base[k]) + 1e-6) for k in base}

    def first_alarm(traj):
        """traj: list[dict(指标)]，返回每个指标首次 |z|>3 的代次（从不告警=∞）"""
        hit = {}
        for t, m in enumerate(traj):
            for k in m:
                z = abs(m[k] - mu[k]) / sg[k]
                if z > 3 and k not in hit: hit[k] = t
        return hit

    faults = {}
    # F1 MAD 自食：自产占比升、覆盖降、uses 向少数集中
    def run_mad(seed):
        lib = M.make_library(240, seed=seed); traj = []
        for g in range(12):
            # 替换式自食：删掉尾部 20 条多样记忆，换成 5 条被反复合成的"均值记忆"
            lib = sorted(lib, key=lambda e: e["id"])[:220]
            for j in range(5):
                lib.append(dict(id="S%d%02d" % (g, j), topic=lib[j % 20]["topic"], true_quality=0.5,
                                keywords=M.TOPIC_WORDS[lib[j % 20]["topic"]][:3], content=[],
                                importance=8, honest_imp=8, vanity=False, created_day=365,
                                t_invalid=None, truly_invalid=False, uses=20, links=[], is_farm=False))
            traj.append(_metrics(lib, self_made=(g + 1) * 5 / len(lib)))
        return traj
    # F2 马太：uses 优先连接滚寡头
    def run_matthew(seed):
        lib = M.make_library(240, seed=seed); rnd = random.Random(seed); w = [1.0] * len(lib); traj = []
        for g in range(12):
            for _ in range(250):
                i = rnd.choices(range(len(lib)), weights=w, k=1)[0]; lib[i]["uses"] += 1; w[i] += 1
            traj.append(_metrics(lib))
        return traj
    # F3 imp 注水：自报 imp 逐步刷满
    def run_vanity(seed):
        lib = M.make_library(240, seed=seed); rnd = random.Random(seed); traj = []
        for g in range(12):
            for e in lib:
                if rnd.random() < 0.05 * (g + 1): e["importance"] = 10
            traj.append(_metrics(lib))
        return traj
    # F4 分布式后门：互链块、入度异常
    def run_collusion(seed):
        lib = M.make_library(240, seed=seed); traj = []
        for g in range(12):
            payload = dict(id="C%d" % g, topic=lib[g]["topic"], true_quality=0.1, keywords=["方法"],
                           content=[], importance=5, honest_imp=5, vanity=False, created_day=365,
                           t_invalid=None, truly_invalid=False, uses=0, links=[], is_farm=True)
            for j in range(4):
                lib.append(dict(id="CB%d%02d" % (g, j), topic=payload["topic"], true_quality=0.2,
                                keywords=M.TOPIC_WORDS[payload["topic"]][:1], content=[],
                                importance=5, honest_imp=5, vanity=False, created_day=365,
                                t_invalid=None, truly_invalid=False, uses=0, links=["C%d" % g], is_farm=True))
            lib.append(payload)
            traj.append(_metrics(lib))
        return traj
    # F5 主题塌缩（新鲜数据断供）：覆盖逐步下降
    def run_starve(seed):
        lib = M.make_library(240, seed=seed); traj = []
        topics_kept = sorted(M.TOPICS)
        for g in range(12):
            drop = topics_kept.pop()
            lib = [e for e in lib if e["topic"] != drop]
            traj.append(_metrics(lib, self_made=0.2))
        return traj

    for name, fn in [("MAD自食", run_mad), ("马太", run_matthew), ("imp注水", run_vanity),
                     ("分布式后门", run_collusion), ("主题塌缩", run_starve)]:
        per_metric_first = {k: [] for k in mu}
        for s in SEEDS:
            hit = first_alarm(fn(s))
            for k in mu: per_metric_first[k].append(hit.get(k, 99))
        faults[name] = {k: (mean(v), round(sum(1 for x in v if x < 99) / len(v), 3))
                        for k, v in per_metric_first.items()}  # (平均首警代, 命中率)
    return faults

# ==========================================================================
# E60 词面鸿沟：同义表述使词面命中崩塌；查询扩展/概念归一救回，但扩展有误入代价
# ==========================================================================
SYN = {}   # 每个主题词 -> 一个"同义异形"字符串（加前缀◇，保证子串不重叠）
def _build_syn():
    for tp, ws in M.TOPIC_WORDS.items():
        for w in ws: SYN[w] = "同义" + w
_build_syn()
def e60(seed, p_syn, mode="none"):
    """p_syn=查询词被同义替换概率；mode: none/query_expand/concept_norm。"""
    rnd = random.Random(seed)
    lib = M.make_library(260, seed=seed, vanity_frac=0.0)
    if mode == "concept_norm":   # 写入侧概念归一：每条 keywords 补上同义词
        for e in lib: e["keywords"] = e["keywords"] + [SYN.get(w, w) for w in e["keywords"]]
    qs = M.make_queries(lib, 80, seed=700 + seed)
    hits, prec = 0, 0.0
    for item in qs:
        words = item["query"].split()
        used = []
        for w in words:
            if rnd.random() < p_syn and w in SYN:
                sw = SYN[w]
                used.append(sw)
                if mode == "query_expand":
                    used.append(w)                         # 理想：同义词+原词一起检
                    if rnd.random() < 0.2:                # 词表不完美：20% 概率并入一个歧义无差别泛词
                        used.append(rnd.choice(sorted(M.GENERIC_WORDS)))
            else:
                used.append(w)
        q = " ".join(used)
        rl = M.rank(lib, q, M.FACTORY)[:5]
        top = [fid for fid, _ in rl]; exp = set(item["expected"])
        if set(top) & exp: hits += 1
        prec += len(set(top) & exp) / 5
    return round(hits / len(qs), 3), round(prec / len(qs), 3)

# ==========================================================================
# E61 自演化路径依赖/多峰：不同初始 θ 爬山是否收敛到不同局部最优；多起点是否更稳
# ==========================================================================
def e61():
    starts = {
        "出厂": dict(M.FACTORY),
        "盲信自报(w_imp=4)": dict(M.FACTORY, w_imp=4.0, w_kw=1.0),
        "盲信时效(w_age=1)": dict(M.FACTORY, w_age=1.0),
        "均衡弱化(w全.5)": dict(w_kw=0.5, w_c=0.5, w_imp=0.5, w_age=0.05, d=0.5, filter_zero=False),
    }
    single = {k: [] for k in starts}
    multi = []
    for s in SEEDS:
        lib = M.make_library(260, seed=s, vanity_frac=0.12)
        q = M.make_queries(lib, 80, seed=800 + s)
        finals = {}
        for name, t0 in starts.items():
            traj = M.evolve(lib, q, q, dict(t0), n_gen=30, seed=s)
            finals[name] = traj[-1][1]
            single[name].append(traj[-1][1])
        # 多起点：4 个起点各爬山，取训练分最高的终点参数再评 hold
        best = -1; best_hold = 0
        for name, t0 in starts.items():
            traj = M.evolve(lib, q, q, dict(t0), n_gen=30, seed=s + 500)
            if traj[-1][0] > best: best, best_hold = traj[-1][0], traj[-1][1]
        multi.append(best_hold)
    return {k: (mean(v), sd(v), round(min(v), 3), round(max(v), 3)) for k, v in single.items()}, \
           (mean(multi), sd(multi))

# ==========================================================================
def main():
    line("=" * 94)
    line("第九轮 E56-E61：分布式合谋、身份治理与可观测性（8 种子均值，确定性可复现）")
    line("=" * 94)

    line("\n### E56 组合式分布式后门（载荷零激活词，k 桥罕见共现经 links 累加抬升）")
    line("%-6s | %-30s | %-30s | %-12s | %-12s" % (
        "桥数k", "闸门关:常规暴露/触发激活", "闸门开:常规暴露/触发激活", "逐条审计命中", "图审计命中"))
    for k in [2, 3, 4, 6]:
        off = [e56(s, k, False) for s in SEEDS]; on = [e56(s, k, True) for s in SEEDS]
        z = lambda xs, i: mean([x[i] for x in xs])
        line("%-6s | %-30s | %-30s | %-12s | %-12s" % (
            "k=%d" % k,
            "%.3f / %.3f" % (z(off, 0), z(off, 1)),
            "%.3f / %.3f" % (z(on, 0), z(on, 1)),
            z(off, 2), z(off, 3)))
    line("=> 逐条审计对分摊后的零件 0 检出；闸门关时多桥共现激活、常规少量共现不激活；闸门开则载荷零命中被删（结构屏障）；图审计靠高入度+贫乏词面抓回")

    line("\n### E57 女巫攻击（诚实源固定 8，攻击者造 n_sybil 个'温和恶意'身份，值=被带偏概率）")
    e57res = e57()
    grid = e57res["mean"][0]
    line("n_sybil " + "".join("%-8s" % n for n in grid))
    for mode in ["mean", "median", "trimmed", "median+年龄门槛"]:
        _, row = e57res[mode]
        line("%-14s" % mode + "".join("%-8s" % v for v in row))
    line("=> mean 被平滑拉高、median 在女巫占比过半(n_sybil=8)处相变突跳，一切按源聚合在多数被占时失效；年龄/信誉门槛把新源权重压到 1/10 后全程免疫——唯一防线是'造身份有成本'")

    line("\n### E58 检测延迟→污染固化（β=.30,γ=.40 即时本可清干净；未固化污染每代 8% 被提升进长期层、不可逆）")
    line("%-10s %-18s %-18s" % ("延迟L代", "最终固化污染", "总污染(固化+残留)"))
    for L in [0, 2, 5, 10, 20]:
        sol, tot = e58(L=L)
        line("%-10s %-18s %-18s" % (L, sol, tot))
    s0, t0 = e58_block_beta0(L=10)
    line("对照 阻断二次写回β=0(L=10): 固化=%s 总污染=%s（延迟再久也不扩散）" % (s0, t0))
    line("=> 清洗率 γ>β 只在'即时'成立；检测延迟让污染在 tau 代内固化、此后 γ 再高也清不掉；根治靠把 β 降到 0")

    line("\n### E59 健康仪表盘（5 类故障 × 5 个纯内部指标，单元格=平均首警代/命中率，∞=该指标看不见此故障）")
    faults = e59()
    metrics_order = ["uses_gini", "imp_mean", "cover", "self_made", "max_indeg"]
    line("%-12s" % "故障＼指标" + "".join("%-18s" % m for m in metrics_order))
    for fname, row in faults.items():
        cells = []
        for m in metrics_order:
            t, hitrate = row[m]
            cells.append(("∞" if hitrate == 0 else "g%d(%.0f%%)" % (t, hitrate * 100)))
        line("%-12s" % fname + "".join("%-18s" % c for c in cells))
    # 最小指标覆盖集（贪心：每步选覆盖故障最多的指标）
    cover_sets = {}
    for m in metrics_order:
        cover_sets[m] = {f for f in faults if faults[f][m][1] >= 0.9}
    remain, chosen = set(faults), []
    while remain:
        best = max(sorted(cover_sets), key=lambda m: len(cover_sets[m] & remain))
        if not (cover_sets[best] & remain): break
        chosen.append(best); remain -= cover_sets[best]
    line("贪心最小领先指标集: " + " + ".join(chosen) + "；仍看不见的故障: " + (",".join(sorted(remain)) or "无"))

    line("\n### E60 词面鸿沟（查询同义替换概率 p_syn；recall/precision）")
    line("%-8s %-22s %-22s %-22s" % ("p_syn", "不处理", "查询扩展(20%歧义)", "写入侧概念归一"))
    for p in [0.0, 0.3, 0.6, 1.0]:
        a = [e60(s, p, "none") for s in SEEDS]; b = [e60(s, p, "query_expand") for s in SEEDS]
        c = [e60(s, p, "concept_norm") for s in SEEDS]
        z = lambda xs, i: mean([x[i] for x in xs])
        line("%-8s %-22s %-22s %-22s" % (
            p, "%.3f/%.3f" % (z(a, 0), z(a, 1)), "%.3f/%.3f" % (z(b, 0), z(b, 1)),
            "%.3f/%.3f" % (z(c, 0), z(c, 1))))
    line("=> 纯词面检索随同义比例线性崩；查询扩展/概念归一救回召回，但扩展把额外词拉入、precision 有代价")

    line("\n### E61 自演化路径依赖（不同初始 θ 各 8 种子爬山 30 代，终态 hold recall 均值/sd/区间）")
    single, multi = e61()
    for name, (m, s_, lo, hi) in single.items():
        line("  %-20s %.3f sd=%.3f [%s,%s]" % (name, m, s_, lo, hi))
    line("  %-20s %.3f sd=%.3f" % ("多起点取最优", multi[0], multi[1]))
    line("=> 差起点（盲信自报/时效）会收敛到次优局部峰；多起点重启显著更稳更高，单起点自演化需要元层兜底")

    line("\n" + "=" * 94)
    line("第九轮完成 E56-E61 共 6 个实验")
    line("=" * 94)

if __name__ == "__main__":
    main()
