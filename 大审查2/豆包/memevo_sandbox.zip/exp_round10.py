# -*- coding: utf-8 -*-
"""
第十轮 E62-E66：非平稳、公平与元过程（non-stationarity, fairness & meta-dynamics）
第九轮把"分布式合谋/身份/可观测"闭合后，本轮问五个时间与过程层面的问题：
  E62 周期性/回归性概念漂移：去而复返的知识，固定 TTL 会不会当过时清掉、慢性层能否复活
  E63 长尾公平：Zipf 查询频率下 LFU 如何窒息稀有主题，配额/时间折扣/探索如何救
  E64 合法多观点被错误合并(E46/E56 对偶)：高相似去重会不会误杀"都对但视角不同"
  E65 金尺本身缓慢漂移(元层版)：用户需求合法迁移时，冻结参数 vs 滑动金尺的追踪滞后
  E66 反身性闭环(performative)：评测从"自己常检索到的地方"出，内部指标与外部金尺如何背离
全部局部 random.Random(seed)、并列加 id tiebreak、集合先 sorted；8 种子均值、无计时实验、两次运行逐行一致。
文献锚点：recurring concepts / continual learning；Zipf/长尾公平与机会均等；
观点多样性与去重误并；concept drift 追踪/滑动窗口；performative prediction(Perdomo 2020)/reflexivity。
"""
import random, math, statistics
import mem_common as M

SEEDS = [11, 23, 37, 51, 67, 83, 101, 127]
def mean(x): return round(statistics.mean(x), 3) if x else 0.0
def sd(x):   return round(statistics.pstdev(x), 3) if len(x) > 1 else 0.0
def gini(vals):
    s = sorted(vals); n = len(s); cum = sum(i * v for i, v in enumerate(s, 1)); tot = sum(s)
    return round((2 * cum) / (n * tot) - (n + 1) / n, 3) if tot > 0 else 0.0

# ── 通用：按指定主题权重确定性地造查询（expected=该主题质量最高的有效条目）──
def weighted_queries(lib, topic_weight, n_q, rng, gold_pool=None):
    """按主题权重造查询。查询词【取自 gold 自身 keywords】（去掉泛词），
    使一次未命中只可能来自'记忆缺失/排序差'而非随机抽词抽偏；gold_pool 给定时
    gold 从 gold_pool 选（用于 E62：真值来自完整库、在存活子集上检索）。"""
    by = {}
    for e in lib: by.setdefault(e["topic"], []).append(e)
    gp = {}
    for e in (gold_pool or []): gp.setdefault(e["topic"], []).append(e)
    topics = [tp for tp in sorted(by) if topic_weight.get(tp, 0.0) > 0]
    if not topics: return []
    w = [topic_weight[tp] for tp in topics]
    tot = sum(w) or 1.0
    probs = [x / tot for x in w]
    qs = []
    for _ in range(n_q):
        r = rng.random(); acc = 0.0; tp = topics[-1]
        for t, p in zip(topics, probs):
            acc += p
            if r <= acc: tp = t; break
        source = gp.get(tp) if gp else by[tp]
        pool = sorted([e for e in source if not e.get("truly_invalid")],
                      key=lambda e: (-e["true_quality"], e["id"]))
        if len(pool) < 1: continue
        gold = pool[:1]
        own = [x for x in gold[0]["keywords"] if x not in M.GENERIC_WORDS]
        cand = sorted(set(own)) if own else sorted(M.TOPIC_WORDS[tp])
        if len(cand) < 2: cand = sorted(M.TOPIC_WORDS[tp])
        wl = rng.sample(cand, 2)
        qs.append(dict(topic=tp, query=" ".join(wl), expected=[e["id"] for e in gold]))
    return qs

# ==========================================================================
# E62 周期性概念漂移：固定 TTL 出仓 vs 慢性层（冷降权、重新命中即复活）
# ==========================================================================
def e62_all(seed):
    rnd = random.Random(seed)
    lib = M.make_library(400, seed=seed, now_day=0)
    for e in lib: e["created_day"] = 0
    by = {}
    for e in lib: by.setdefault(e["topic"], []).append(e)
    topics = sorted(by)
    phase = {tp: i / len(topics) for i, tp in enumerate(topics)}
    period = 24; T_cold = 6; G = 72
    def heat(tp, g): return max(0.0, math.sin(2 * math.pi * (g / period - phase[tp])))
    def active(tp, g): return heat(tp, g) > 0.3
    def run(strategy):
        r2 = random.Random(seed + len(strategy))   # 两策略用同一查询流（不同确定源但同分布）
        alive = {e["id"]: e for e in lib}; chronic = set()
        last_active = {tp: 0 for tp in topics}; adopt = {e["id"]: 0 for e in lib}
        hits, n = 0, 0; prev = {tp: active(tp, 0) for tp in topics}
        for g in range(G):
            for tp in topics:
                a = active(tp, g)
                if a: last_active[tp] = g
                if a and not prev[tp]:
                    # 回归点：gold=完整库质量 top1（真值），查询词取自其 keywords；在存活子集上检索
                    gold = sorted([e for e in by[tp] if not e.get("truly_invalid")],
                                  key=lambda e: (-e["true_quality"], e["id"]))[:1]
                    if gold:
                        own = sorted({w for w in gold[0]["keywords"] if w not in M.GENERIC_WORDS})
                        if len(own) >= 2:
                            n += 1
                            if gold[0]["id"] in alive:   # gold 已被出仓直接记 miss
                                wl = r2.sample(own, 2)
                                rl = [f for f, _ in M.rank(list(alive.values()), " ".join(wl),
                                                           M.FACTORY, now_day=g)[:5]]
                                if set(rl) & {gold[0]["id"]}: hits += 1
                prev[tp] = a
                if a:
                    for q in weighted_queries(list(alive.values()), {tp: 1.0}, 2, r2):
                        for fid, _ in M.rank(list(alive.values()), q["query"], M.FACTORY, now_day=g)[:5]:
                            adopt[fid] += 1; chronic.add(fid)
                if g - last_active[tp] > T_cold:
                    for e in by[tp]:
                        if strategy == "fixed_ttl" or e["id"] not in chronic: alive.pop(e["id"], None)
        return round(hits / max(1, n), 3), round(len(alive) / len(lib), 3)
    return run("fixed_ttl"), run("chronic")

# ==========================================================================
# E63 长尾公平：Zipf 查询 + 预算逐出，比较 LFU/主题配额/时间折扣/探索
# ==========================================================================
def _zipf_weights(topics, s=1.0):
    w = [(i + 1) ** (-s) for i in range(len(topics))]
    return dict(zip(topics, w))

def e63(seed, policy, budget=200, G=40):
    rnd = random.Random(seed)
    lib = M.make_library(400, seed=seed)
    for e in lib: e["uses"] = 0          # 公平起点：uses 完全由 Zipf 采用流累积，马太才纯粹
    topics = sorted(M.TOPICS); zw = _zipf_weights(topics, 1.5)
    decay_uses = {e["id"]: 0.0 for e in lib}
    id2 = {e["id"]: e for e in lib}
    explore = (policy == "lfu_explore")
    by_topic = {}
    for e in lib:
        if not e.get("truly_invalid"): by_topic.setdefault(e["topic"], []).append(e)
    for g in range(G):
        wq = dict(zw)
        if explore:  # ε=0.15 质量均匀分给所有主题
            for tp in topics: wq[tp] = 0.85 * wq[tp] + 0.15 / len(topics)
        # 采用直接按"查询主题"惠及该主题随机 3 条：出厂排序不含 uses，主题热度必须这样才能传到条目存活
        for q in weighted_queries(lib, wq, 40, rnd):
            pool = by_topic.get(q["topic"], [])
            for e in rnd.sample(pool, min(3, len(pool))):
                if policy == "time_decay": decay_uses[e["id"]] += 1
                else: e["uses"] += 1
        if policy == "time_decay":
            for e in lib:
                decay_uses[e["id"]] *= 0.9
                e["uses"] = int(decay_uses[e["id"]])
    # 预算逐出
    if policy == "topic_quota":
        keep = []; by = {}
        for e in lib: by.setdefault(e["topic"], []).append(e)
        cap = math.ceil(budget / len(topics))
        for tp in topics:
            keep += sorted(by[tp], key=lambda e: (-e["uses"], e["id"]))[:cap]
        lib2 = keep
    else:
        lib2, _ = M.evict_to_budget(lib, budget, "lru")
    # 均匀"厚度"测试：expected 取自【逐出前完整库】的该主题 3 条有效条目，在留存库 lib2 上检索
    # ——被逐出的条目不进 top5 即记 miss，避免"只考幸存条目"的幸存者偏差
    full_by = {}
    for e in lib:
        if not e.get("truly_invalid"): full_by.setdefault(e["topic"], []).append(e)
    def breadth_queries(tpset, n_q):
        qs = []
        tps = [t for t in topics if t in tpset and full_by.get(t)]
        for _ in range(n_q):
            if not tps: break
            tp = rnd.choice(tps); pool = sorted(full_by[tp], key=lambda e: e["id"])
            exp = rnd.sample(pool, min(3, len(pool)))
            words = sorted({w for e in exp for w in e["keywords"] if w not in M.GENERIC_WORDS})
            if len(words) < 2: continue
            qs.append(dict(topic=tp, query=" ".join(rnd.sample(words, 2)),
                           expected=[e["id"] for e in exp]))
        return qs
    q_all = breadth_queries(set(topics), 100)
    q_tail = breadth_queries(set(topics[10:]), 60)
    ov = M.evaluate(lib2, q_all, M.FACTORY)["recall"]
    tv = M.evaluate(lib2, q_tail, M.FACTORY)["recall"] if q_tail else 0.0
    covered = len({e["topic"] for e in lib2})
    g = gini([e["uses"] for e in lib2])
    # 留存公平：热门(前10)与长尾(后10)主题各自平均存活条数（马太在留存侧最直接可见）
    keep_by = {}
    for e in lib2: keep_by[e["topic"]] = keep_by.get(e["topic"], 0) + 1
    head = round(statistics.mean(keep_by.get(tp, 0) for tp in topics[:10]), 2)
    tail = round(statistics.mean(keep_by.get(tp, 0) for tp in topics[10:]), 2)
    return round(ov, 3), round(tv, 3), covered, g, head, tail

# ==========================================================================
# E64 合法多观点 vs 事实冲突：相似度去重的误杀，及"矛盾类型判别"
# ==========================================================================
def _jacc(a, b):
    sa, sb = set(a), set(b)
    return len(sa & sb) / max(1, len(sa | sb))

def _build_clusters(seed, n=40):
    rnd = random.Random(seed); clusters = []
    for i in range(n):
        tp = sorted(M.TOPICS)[i % len(M.TOPICS)]; words = sorted(M.TOPIC_WORDS[tp])
        # 冲突簇：共享 3 词、各再带 1 个不同独有词 → Jaccard=3/5=0.6；一真(高uses)一假(零uses)
        shared = rnd.sample(words, 3)
        rest = [w for w in words if w not in shared]; d1, d2 = rnd.sample(rest, 2)
        hi = dict(id="C%da" % i, topic=tp, true_quality=0.85, keywords=shared + [d1], content=[],
                  importance=8, honest_imp=8, vanity=False, created_day=300, t_invalid=None,
                  truly_invalid=False, uses=30, links=[], is_farm=False)
        lo = dict(id="C%db" % i, topic=tp, true_quality=0.10, keywords=shared + [d2],
                  content=[], importance=8, honest_imp=2, vanity=True, created_day=300, t_invalid=None,
                  truly_invalid=True, uses=0, links=[], is_farm=False)
        clusters.append(("conflict", hi, lo))
    for i in range(n):
        tp = sorted(M.TOPICS)[(i + 7) % len(M.TOPICS)]; words = sorted(M.TOPIC_WORDS[tp])
        # 互补簇：共享 1~2 词、各带不同独有词 → Jaccard 0.2~0.5；都真、都有下游采用
        k = rnd.choice([1, 2]); shared = rnd.sample(words, k)
        rest = [w for w in words if w not in shared]
        uniq = rnd.sample(rest, 4); u1, u2, u3, u4 = uniq
        a = dict(id="V%da" % i, topic=tp, true_quality=0.75, keywords=shared + [u1, u2], content=[],
                 importance=7, honest_imp=7, vanity=False, created_day=300, t_invalid=None,
                 truly_invalid=False, uses=20, links=[], is_farm=False)
        b = dict(id="V%db" % i, topic=tp, true_quality=0.72, keywords=shared + [u3, u4], content=[],
                 importance=7, honest_imp=7, vanity=False, created_day=300, t_invalid=None,
                 truly_invalid=False, uses=18, links=[], is_farm=False)
        clusters.append(("complement", a, b))
    return clusters

def e64(seed, theta, smart=False):
    """返回 (冲突正确处理率, 互补误杀率)。去重：sim>=theta 合并（保留 uses 高者）。
    smart=True：还要 uses 悬殊（>=4 倍或其一为 0）才判事实冲突合并，否则视为互补保留。"""
    clusters = _build_clusters(seed)
    conflict_ok, complement_kill = 0, 0
    nc = nv = 0
    for kind, a, b in clusters:
        sim = _jacc(a["keywords"], b["keywords"])
        uses_gap = (max(a["uses"], b["uses"]) >= 4 * max(1, min(a["uses"], b["uses"]))) or \
                   (a["uses"] == 0 or b["uses"] == 0)
        merge = sim >= theta and (not smart or uses_gap)
        if kind == "conflict":
            nc += 1
            # 正确：低质 b 被并掉、高质 a 留下
            if merge and min(a["uses"], b["uses"]) == b["uses"]: conflict_ok += 1
        else:
            nv += 1
            if merge: complement_kill += 1      # 两个都对却被并=误杀
    return round(conflict_ok / max(1, nc), 3), round(complement_kill / max(1, nv), 3)

# ==========================================================================
# E65 金尺缓慢漂移：冻结参数 vs 滑动窗口追踪 vs 当代 oracle
# ==========================================================================
def _world_queries(lib, alpha, seed):
    """alpha=1 偏词面(A 世界)，alpha=0 偏时效(B 世界：新条目更优)。按 alpha 混合两套查询。"""
    rnd = random.Random(seed)
    qs = M.make_queries(lib, 80, seed=seed)
    return qs, alpha

def e65(seed, period=24, G=48):
    lib = M.make_library(300, seed=seed, now_day=365)
    # A 世界=标准库；B 世界：人为抬高"新条目"质量、压低"老条目"，使最优偏 w_age
    libB = [dict(e) for e in lib]
    for e in libB:
        age = 365 - e["created_day"]
        e["true_quality"] = round(min(1.0, max(0.0, e["true_quality"] + (0.8 if age < 60 else -0.4))), 3)
    qA = M.make_queries(lib, 80, seed=500 + seed)
    qB = M.make_queries(libB, 80, seed=600 + seed)
    def mix(alpha):
        nA = int(round(alpha * len(qA))); return qA[:nA] + qB[:len(qB) - nA]
    def score_on(theta, alpha, libA=lib, libB_=libB):
        q = mix(alpha); nA = int(round(alpha * len(qA)))
        sA = M.evaluate(libA, q[:nA], theta)["recall"] if nA else 0.0
        sB = M.evaluate(libB_, q[nA:], theta)["recall"] if len(q) - nA else 0.0
        return round(alpha * sA + (1 - alpha) * sB, 3)
    # 当代上界=固定候选参数网格内最优（确定性、必不低于爬山策略）
    grid = []
    for wk in (2.0, 3.0, 4.5, 6.0):
        for wa in (0.03, 0.1, 0.25, 0.5):
            for wi in (0.5, 1.0, 2.0):
                grid.append(dict(w_kw=wk, w_c=1.0, w_imp=wi, w_age=wa, d=0.5, filter_zero=False))
    # 冻结：在 g=0(alpha=.5) 一次演化后固定
    a0 = 0.5
    frozen = M.evolve(lib, mix(a0), mix(a0), dict(M.FACTORY), n_gen=25, seed=seed)[-1][2]
    theta_slide = dict(M.FACTORY)
    theta_or = dict(M.FACTORY)        # 理想追踪者：同样热启、但每代搜索 5 倍代数=追踪上界
    fr, sr, og, lag, wob = [], [], [], [], []
    prev = None
    for g in range(G):
        alpha = 0.5 + 0.5 * math.sin(2 * math.pi * g / period)
        fr.append(score_on(frozen, alpha))
        qg = mix(alpha)
        theta_slide = M.evolve(lib, qg, qg, dict(theta_slide), n_gen=3, seed=seed + g)[-1][2]
        sr.append(score_on(theta_slide, alpha))
        theta_or = M.evolve(lib, qg, qg, dict(theta_or), n_gen=15, seed=seed + g + 700)[-1][2]
        best_o = max([score_on(t, alpha) for t in grid] + [score_on(theta_or, alpha)])
        og.append(best_o)
        lag.append(best_o - sr[-1])
        if prev is not None:
            wob.append(abs(theta_slide["w_age"] - prev["w_age"]) + abs(theta_slide["w_kw"] - prev["w_kw"]))
        prev = dict(theta_slide)
    return dict(frozen=mean(fr), slide=mean(sr), oracle=mean(og),
                lag=mean(lag), wobble=mean(wob))

# ==========================================================================
# E66 反身性闭环：内部评测从"自己常检索处"出 → 内外剪刀差
# ==========================================================================
def _topic_hit_weights(lib, theta):
    """用当前 theta 全库检索探针，统计 top3 命中主题频次（系统'擅长/常检索'处）。"""
    by = {}
    for e in lib: by.setdefault(e["topic"], []).append(e)
    hits = {tp: 0 for tp in sorted(by)}
    probe = M.make_queries(lib, 60, seed=12345)
    id2 = {e["id"]: e for e in lib}
    for q in probe:
        for fid, _ in M.rank(lib, q["query"], theta)[:3]:
            hits[id2[fid]["topic"]] += 1
    return hits

def e66(seed, G=30):
    lib = M.make_library(300, seed=seed)
    q_ext = M.make_queries(lib, 120, seed=3000 + seed)    # 外部金尺：固定、均匀、覆盖全主题
    topics = sorted(M.TOPICS)
    def run(reflexive):
        rnd = random.Random(seed)
        theta = dict(M.FACTORY)
        self_w = {tp: 1.0 for tp in topics}               # 自指主题权重（乘性马太、逐代锁定）
        track = []
        for g in range(G + 1):
            if reflexive:
                q_int = weighted_queries(lib, self_w, 80, rnd)
                internal = M.evaluate(lib, q_int, theta)["recall"]
            else:
                internal = M.evaluate(lib, q_ext, theta)["recall"]
            external = M.evaluate(lib, q_ext, theta)["recall"]
            track.append((g, internal, external))
            if g == G: break
            if reflexive:
                hits = _topic_hit_weights(lib, theta)
                # 乘性正反馈：命中越多权重放大越快（+eps 保底），分布逐代锁死到少数主题
                for tp in topics:
                    self_w[tp] *= (1.0 + 0.6 * hits.get(tp, 0))
                    self_w[tp] = max(self_w[tp], 0.02)
                train_q = weighted_queries(lib, self_w, 80, rnd)
            else:
                train_q = list(q_ext)
            theta = M.evolve(lib, train_q, q_ext, dict(theta), n_gen=4, seed=seed + g)[-1][2]
        return track
    t_self, t_ctrl = run(True), run(False)
    def gap(t): return round(t[-1][1] - t[-1][2], 3)
    return dict(self_internal=t_self[-1][1], self_external=t_self[-1][2], self_gap=gap(t_self),
                ctrl_internal=t_ctrl[-1][1], ctrl_external=t_ctrl[-1][2], ctrl_gap=gap(t_ctrl),
                self_curve=[(g, i, x) for g, i, x in t_self if g in (0, 5, 10, 20, 30)])

# ==========================================================================
def main():
    L = print
    L("=" * 96)
    L("第十轮 E62-E66：非平稳、公平与元过程（8 种子均值，确定性可复现）")
    L("=" * 96)

    L("\n### E62 周期性概念漂移（去而复返；回归点 recall / 末态存储占比）")
    a, b = [], []
    for s in SEEDS:
        fa, ch = e62_all(s); a.append(fa); b.append(ch)
    L("%-16s %-22s %-22s" % ("策略", "回归期 recall", "末态存储占比"))
    L("%-16s %-22s %-22s" % ("固定TTL出仓", mean([x[0] for x in a]), mean([x[1] for x in a])))
    L("%-16s %-22s %-22s" % ("慢性层(可复活)", mean([x[0] for x in b]), mean([x[1] for x in b])))
    L("=> 固定 TTL 把'还会回来'的主题在冷却后清掉、回归时召回崩；慢性层冷降权不出仓、重新命中即复活，代价是多占存储")

    L("\n### E63 长尾公平（Zipf s=1.5 查询 40 代后预算 400→200；整体/长尾 recall、覆盖、uses 基尼、热门/长尾平均存活条数）")
    L("%-14s %-10s %-10s %-8s %-9s %-12s" % ("逐出策略", "整体", "长尾", "覆盖", "uses基尼", "热门/长尾存活"))
    for pol, name in [("lru", "LFU(基线)"), ("time_decay", "时间折扣uses"),
                      ("lfu_explore", "LFU+15%探索"), ("topic_quota", "按主题配额")]:
        rows = [e63(s, pol) for s in SEEDS]
        L("%-14s %-10s %-10s %-8s %-9s %s/%s" % (
            name, mean([r[0] for r in rows]), mean([r[1] for r in rows]),
            round(statistics.mean([r[2] for r in rows]), 1), mean([r[3] for r in rows]),
            round(statistics.mean([r[4] for r in rows]), 1), round(statistics.mean([r[5] for r in rows]), 1)))
    L("=> LFU 在陡 Zipf 下把预算几乎全给热门主题、长尾主题只剩独苗；时间折扣削累积反伤、15% 随机探索力度不足，按主题配额把长尾存活与召回拉平、整体还更高（机会均等要靠结构性配额而非随机探索）")

    L("\n### E64 合法多观点 vs 事实冲突（冲突正确处理率 / 互补观点误杀率）")
    L("%-22s %-18s %-18s" % ("去重方式", "冲突正确合并", "互补误杀"))
    for th in [0.3, 0.5, 0.7]:
        rows = [e64(s, th, False) for s in SEEDS]
        L("纯相似度 θ=%.1f          %-18s %-18s" % (
            th, mean([r[0] for r in rows]), mean([r[1] for r in rows])))
    rows = [e64(s, 0.5, True) for s in SEEDS]
    L("%-22s %-18s %-18s" % ("θ=.5+矛盾类型判别", mean([r[0] for r in rows]), mean([r[1] for r in rows])))
    L("=> 低 θ 能并掉冲突却大量误杀合法多观点、高 θ 保住多样又漏冲突；必须叠加'uses 悬殊=事实冲突'判别才能两头占")

    L("\n### E65 金尺本身缓慢漂移（一个正弦周期内平均 recall；oracle 为当代上界）")
    rows = [e65(s) for s in SEEDS]
    for k, name in [("frozen", "冻结参数(一次性演化)"), ("slide", "滑动窗口持续追踪"), ("oracle", "当代oracle上界")]:
        L("  %-22s %.3f" % (name, mean([r[k] for r in rows])))
    L("  平均追踪滞后(oracle-滑动) %s；滑动参数代际震荡 %s" % (
        mean([r["lag"] for r in rows]), mean([r["wobble"] for r in rows])))
    L("=> 金尺合法迁移时冻结参数必然滞后；滑动窗口金尺能以小幅参数震荡追踪，这是'人侧主动换尺'而非尺子被污染(区别 E15/E42)")

    L("\n### E66 反身性闭环（30 代；内部自测 recall / 外部金尺 recall / 剪刀差）")
    rows = [e66(s) for s in SEEDS]
    L("%-20s %-16s %-16s %-10s" % ("模式", "末态内部", "末态外部", "剪刀差"))
    L("%-20s %-16s %-16s %-10s" % ("自指评测", mean([r["self_internal"] for r in rows]),
                                   mean([r["self_external"] for r in rows]), mean([r["self_gap"] for r in rows])))
    L("%-20s %-16s %-16s %-10s" % ("外部覆盖对照", mean([r["ctrl_internal"] for r in rows]),
                                   mean([r["ctrl_external"] for r in rows]), mean([r["ctrl_gap"] for r in rows])))
    L("自指评测轨迹(代,内部,外部): " + "  ".join(
        "g%d:%.3f/%.3f" % (g, mean([[x for x in r["self_curve"] if x[0] == g][0][1] for r in rows]),
                           mean([[x for x in r["self_curve"] if x[0] == g][0][2] for r in rows]))
        for g in (0, 5, 10, 20, 30)))
    L("=> 评测只从'系统已擅长处'出，内部自测维持高位、外部金尺停滞，剪刀差随代扩大；强制评测分布外部覆盖则无剪刀差")

    L("\n" + "=" * 96); L("第十轮完成 E62-E66 共 5 个实验"); L("=" * 96)

if __name__ == "__main__":
    main()
