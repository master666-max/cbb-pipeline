"""exp_round1.py — 第一轮：群体智慧何时成立（E1-E3）"""
import random
from agora_common import (correlated_judgments, independent_judgments,
                          acc_majority, continuous_estimates, mean, median,
                          trimmed_mean, mae_over_trials, gauss)

TRIALS = 4000

def hdr(t): print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)

# ---------------- E1 Condorcet 的真实边界 ----------------
hdr("E1 群体何时比个体聪明：Condorcet 的边界（trials=%d）" % TRIALS)
print(f"{'p\\N':>6}" + "".join(f"{n:>9}" for n in (1, 3, 11, 51, 201)))
for p in (0.45, 0.50, 0.55):
    row = [f"{p:>6}"]
    for n in (1, 3, 11, 51, 201):
        rng = random.Random(100 + int(p * 100) + n)
        mat, _ = independent_judgments(rng, n, p, TRIALS)
        row.append(f"{acc_majority(mat):>9.3f}")
    print("".join(row))
print("\n解读：p=0.55 随 N 逼近 1；p=0.45 随 N 逼近 0（人越多越必然地错）；p=0.50 永远是抛硬币")

# ---------------- E2 相关性是隐形毒药 ----------------
hdr("E2 判断相关时，51 个人等于几个独立人（p=0.55, N=51, trials=%d）" % TRIALS)
print(f"{'rho目标':>8}{'rho实测':>9}{'多数决准确率':>14}{'有效样本Neff':>13}{'Neff独立准确率':>15}")
for target in (0.0, 0.1, 0.2, 0.4, 0.6, 0.8):
    rng = random.Random(200 + int(target * 100))
    mat, rho_real = correlated_judgments(rng, 51, 0.55, target, TRIALS)
    acc = acc_majority(mat)
    neff = 51 / (1 + 50 * target)
    rng2 = random.Random(200 + int(target * 100))
    mat_i, _ = independent_judgments(rng2, max(1, round(neff)), 0.55, TRIALS)
    acc_neff = acc_majority(mat_i)
    print(f"{target:>8.2f}{rho_real:>9.3f}{acc:>14.3f}{neff:>13.1f}{acc_neff:>15.3f}")
print("\n解读：rho=0.2 时 51 人 ≈ 4.6 个独立人；rho=0.8 时 ≈ 1.3 个，加人几乎无用")

# ---------------- E3 连续估计：均值/中位/截尾 ----------------
hdr("E3 连续估计聚合器对比（真值=100, sigma=10, N=21, trials=2000）")
agg = {"mean": mean, "median": median,
       "trim10%": trimmed_mean, "trim20%": lambda x: trimmed_mean(x, 0.2)}

def run_world(world_name, mat):
    print(f"\n[{world_name}]  MAE（越小越好）")
    for name, fn in agg.items():
        print(f"  {name:<10}: {mae_over_trials(mat, fn, 100):.3f}")

# 干净世界
rng = random.Random(301)
clean = continuous_estimates(rng, 21, 100, 10, 2000)
run_world("干净世界（无离群）", clean)

# 20% 单侧离群污染（捣乱者统一 +50）
rng = random.Random(302)
polluted = []
for _ in range(2000):
    row = [100 + 10 * gauss(rng) for _ in range(16)] + [150 + 5 * gauss(rng) for _ in range(5)]
    polluted.append(row)
run_world("污染世界（20% 人统一高报 +50）", polluted)

# 单个极端值
rng = random.Random(303)
single = []
for _ in range(2000):
    row = [100 + 10 * gauss(rng) for _ in range(20)] + [1000.0]
    single.append(row)
run_world("单极端值世界（20 正常 + 1 个报 1000）", single)
print("\n解读：干净世界均值最优；一旦存在单侧污染/极端值，均值立刻最差，中位数/截尾稳定")
