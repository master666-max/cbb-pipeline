"""run_all.py — agora 沙盒一键复现：基线探针 + 五轮 18 个实验"""
import io, sys, time

def section(title, module):
    print("\n" + "#"*74)
    print(f"# {title}")
    print("#"*74)
    mod = __import__(module)
    # 模块在 import 时即执行全部实验（顶层脚本），这里仅触发一次

if __name__ == "__main__":
    t0 = time.time()
    section("基线缺陷探针 baseline_review", "baseline_review")
    for r in range(1, 6):
        section(f"第 {r} 轮 exp_round{r}", f"exp_round{r}")
    print(f"\n[全部完成，用时 {time.time()-t0:.1f}s，纯标准库、固定种子可复现]")
