"""agora_common.py — agora 群体智慧沙盒 · 共享世界模型（纯标准库）

约定：
- 所有随机数走显式 rng（random.Random(seed)），保证可复现；
- 二值世界：状态 truth ∈ {0,1}，个体判断为 0/1 或连续估计；
- 相关判断用高斯 copula（共享因子模型）生成，名义 rho 与实测 rho 同时报告，
  绝不把名义相关当真实相关。
"""
import math
import random as _random

# ---------- 基础统计 ----------
def mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs)

def var(xs):
    m = mean(xs)
    return sum((x - m) ** 2 for x in xs) / len(xs)

def std(xs):
    return math.sqrt(var(xs))

def median(xs):
    s = sorted(xs)
    n = len(s)
    if n % 2:
        return s[n // 2]
    return (s[n // 2 - 1] + s[n // 2]) / 2

def trimmed_mean(xs, trim=0.1):
    """两端各裁掉 trim 比例后的均值"""
    s = sorted(xs)
    k = int(len(s) * trim)
    core = s[k: len(s) - k] if k > 0 else s
    return mean(core)

def majority(votes, options=(0, 1)):
    """返回 (胜者, 票差, 是否平票)。平票诚实标记，不偷偷选边。"""
    c = {o: 0 for o in options}
    for v in votes:
        if v in c:
            c[v] += 1
    order = sorted(options, key=lambda o: -c[o])
    top, second = order[0], order[1] if len(order) > 1 else None
    tie = second is not None and c[top] == c[second]
    gap = c[top] - (c[second] if second is not None else 0)
    return top, gap, tie

def kendall_tau(a, b):
    """Kendall's tau-b，用于排序一致性"""
    n = len(a)
    conc = disc = ties_a = ties_b = 0
    for i in range(n):
        for j in range(i + 1, n):
            da = (a[i] > a[j]) - (a[i] < a[j])
            db = (b[i] > b[j]) - (b[i] < b[j])
            if da == 0 and db == 0:
                continue
            if da == 0:
                ties_a += 1
            elif db == 0:
                ties_b += 1
            elif da == db:
                conc += 1
            else:
                disc += 1
    denom = math.sqrt((conc + disc + ties_a) * (conc + disc + ties_b))
    return (conc - disc) / denom if denom else 0.0

def bootstrap_ci_low(diffs, b=2000, rng=None, alpha=0.05):
    """配对差 di = 新-旧 的均值 bootstrap 单侧 95% 下界（E17 风格判据用）"""
    rng = rng or _random.Random(0)
    n = len(diffs)
    means = []
    for _ in range(b):
        means.append(mean(diffs[rng.randrange(n)] for _ in range(n)))
    means.sort()
    return means[int(alpha * b)]

# ---------- 正态工具（无 scipy 依赖）----------
def norm_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))

def norm_ppf(p):
    """Acklam 逆正态 CDF，相对误差 < 1.2e-9"""
    if p <= 0 or p >= 1:
        raise ValueError("p in (0,1)")
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    plow, phigh = 0.02425, 0.97575
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / \
               ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if p <= phigh:
        q = p - 0.5; r = q*q
        return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / \
               (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)
    q = math.sqrt(-2 * math.log(1-p))
    return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / \
            ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)

def gauss(rng):
    """标准正态（rng 自带 gauss 是 Box-Muller，直接用）"""
    return rng.gauss(0, 1)

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

def logit(p, eps=1e-3):
    p = min(1 - eps, max(eps, p))
    return math.log(p / (1 - p))

# ---------- 相关判断生成 ----------
def _latent_rho_for(p, target):
    """高斯 copula 离散化会衰减成对相关，且高段为非线性。用数值二分标定
    潜变量相关，使实测 phi 系数命中目标观测相关。按 (p,target) 缓存。"""
    if target <= 0:
        return 0.0
    key = (round(p, 3), round(target, 3))
    if key in _LATENT_CACHE:
        return _LATENT_CACHE[key]
    thr = norm_ppf(p)
    def measure_phi(latent, trials=1000, n=15):
        r = _random.Random(9999)
        sr, ir = math.sqrt(latent), math.sqrt(1 - latent)
        sp = 0.0; spp = 0.0; npair = 0; tot = 0
        for _ in range(trials):
            g = gauss(r)
            row = [1 if (sr*g + ir*gauss(r)) < thr else 0 for _ in range(n)]
            sp += sum(row); tot += n
            for i in range(0, n - 1, 2):
                spp += row[i]*row[i+1]; npair += 1
        ph = sp/tot
        p11 = spp/npair
        return (p11 - ph*ph)/(ph*(1-ph)) if 0 < ph < 1 else 0.0
    lo, hi = 0.0, 1.0
    for _ in range(14):
        mid = (lo + hi) / 2
        if measure_phi(mid) < target:
            lo = mid
        else:
            hi = mid
    _LATENT_CACHE[key] = (lo + hi) / 2
    return _LATENT_CACHE[key]

_LATENT_CACHE = {}

def correlated_judgments(rng, n, p, rho, trials):
    """等相关高斯 copula：生成 trials×n 的 0/1 判断，边际正确率 p，成对相关≈rho。
    rho 为目标观测相关，内部做离散化标定。返回 (矩阵, 实测平均成对相关)。"""
    thr = norm_ppf(p)
    latent = _latent_rho_for(p, rho)
    srho = math.sqrt(max(latent, 0.0))
    irho = math.sqrt(max(1 - latent, 0.0))
    mat = []
    # 实测相关：每 trial 抽固定 6 对，trials×6 对（约 2.4 万对），保证估计稳定
    pair_prod = 0.0; cnt_pair = 0; samp_p = 0.0; cnt_all = 0
    for t in range(trials):
        common = gauss(rng)
        row = []
        zs = [srho * common + irho * gauss(rng) for _ in range(n)]
        for z in zs:
            row.append(1 if z < thr else 0)
        mat.append(row)
        samp_p += sum(row); cnt_all += n
        step = max(1, n // 3)
        for i in range(0, n - 1, step):
            for j in (i + 1, min(n - 1, i + 1 + step)):
                pair_prod += row[i] * row[j]; cnt_pair += 1
    phat = samp_p/cnt_all
    p11 = pair_prod/cnt_pair if cnt_pair else phat*phat
    denom = phat*(1-phat)
    rho_real = (p11 - phat*phat)/denom if denom > 1e-9 else 0.0
    return mat, rho_real

def independent_judgments(rng, n, p, trials):
    mat = [[1 if rng.random() < p else 0 for _ in range(n)] for _ in range(trials)]
    return mat, 0.0

# ---------- 网络拓扑 ----------
def net_ring(n, k=2):
    return {i: ({(i+j) % n for j in range(1, k+1)} |
                {(i-j) % n for j in range(1, k+1)}) for i in range(n)}

def net_ws(n, k=2, p=0.15, seed=1):
    rng = _random.Random(seed); adj = net_ring(n, k)
    for i in range(n):
        for j in list(adj[i]):
            if j > i and rng.random() < p:
                adj[i].discard(j); adj[j].discard(i)
                t = rng.randrange(n)
                if t != i:
                    adj[i].add(t); adj[t].add(i)
    return adj

def net_full(n):
    return {i: {j for j in range(n) if j != i} for i in range(n)}

def net_ba(n, m=2, seed=1):
    rng = _random.Random(seed); adj = {0: {1}, 1: {0}}
    deg = [1, 1]
    for i in range(2, n):
        targets = set(); degtot = sum(deg)
        while len(targets) < m:
            r = rng.uniform(0, degtot); acc = 0
            for j in range(i):
                acc += deg[j]
                if r <= acc:
                    targets.add(j); break
        adj[i] = set(targets)
        for t in targets:
            adj[t].add(i)
        deg.append(len(targets))
        for t in targets:
            deg[t] += 1
    return adj

def degroot(adj, x0, stubborn=None, agg=mean, maxit=300, tol=1e-4):
    """意见动力学。stubborn={节点:固定值} 的节点不更新；agg=mean/median 决定聚合方式。"""
    x = list(x0); stubborn = stubborn or {}
    for rounds in range(1, maxit+1):
        nx = list(x)
        for i in range(len(x)):
            if i in stubborn:
                nx[i] = stubborn[i]; continue
            nb = list(adj[i] | {i})
            nx[i] = agg([x[j] for j in nb])
        if max(abs(a-b) for a, b in zip(nx, x)) < tol:
            x = nx; return x, rounds
        x = nx
    return x, maxit

def block_correlated_judgments(rng, sizes, p, rho, trials):
    """分块相关：同簇（同一信息源）内成对相关≈rho，簇间独立。
    sizes=[12,6,3,3] -> 24 人；p 可为标量或长度=簇数的列表（每信源各自正确率）。
    返回 (trials×N 矩阵, 每人所属簇)"""
    C = len(sizes)
    if isinstance(p, (list, tuple)):
        thr = [norm_ppf(x) for x in p]
        latent = [_latent_rho_for(p[c], rho) for c in range(C)]
    else:
        thr = [norm_ppf(p)] * C
        latent = [_latent_rho_for(p, rho)] * C
    sr = [math.sqrt(x) for x in latent]
    ir = [math.sqrt(1-x) for x in latent]
    cluster_of = [c for c, sz in enumerate(sizes) for _ in range(sz)]
    mat = []
    for _ in range(trials):
        gcommon = [gauss(rng) for _ in range(C)]
        row = [1 if (sr[c]*gcommon[c] + ir[c]*gauss(rng)) < thr[c] else 0
               for c in cluster_of]
        mat.append(row)
    return mat, cluster_of

def continuous_estimates(rng, n, truth, sigma, trials, bias=0.0):
    """独立连续估计：truth + N(bias, sigma^2)"""
    return [[truth + bias + sigma*gauss(rng) for _ in range(n)] for _ in range(trials)]

def source_flip_judgments(rng, sizes, source_q, flip, trials):
    """信源-翻转模型：每簇一个信源 S_c~Bern(source_q)，簇内每人以 flip 概率翻转 S。
    个体边际正确率 = source_q(1-flip)+(1-source_q)flip；组内多数可还原 S。"""
    cluster_of = [c for c, sz in enumerate(sizes) for _ in range(sz)]
    C = len(sizes)
    mat = []
    for _ in range(trials):
        src = [1 if rng.random() < source_q else 0 for _ in range(C)]
        row = [src[c] ^ (1 if rng.random() < flip else 0) for c in cluster_of]
        mat.append(row)
    return mat, cluster_of

def mae_over_trials(mat, agg_fn, truth):
    return mean([abs(agg_fn(row) - truth) for row in mat])

def acc_majority(mat):
    """二值多数决正确率（平票按 0.5 计）"""
    correct = 0.0
    for row in mat:
        top, gap, tie = majority(row)
        if tie:
            correct += 0.5
        elif top == 1:
            correct += 1
    return correct / len(mat)

if __name__ == "__main__":
    # 自检：逆正态 / 相关生成器是否诚实
    assert abs(norm_cdf(norm_ppf(0.37)) - 0.37) < 1e-6
    rng = _random.Random(42)
    _, rr = correlated_judgments(rng, 21, 0.6, 0.4, 2000)
    print(f"[selfcheck] 名义 rho=0.40 实测 rho={rr:.3f}")
    rng = _random.Random(42)
    m, _ = correlated_judgments(rng, 21, 0.55, 0.0, 3000)
    print(f"[selfcheck] rho=0 时 21 人多数决准确率={acc_majority(m):.3f}（理论≈0.666）")
