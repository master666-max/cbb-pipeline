"""exp_round5.py — 第五轮：治理机制验证（E14-E18）"""
import math, random
from agora_common import (mean, median, trimmed_mean, gauss,
                          independent_judgments, correlated_judgments,
                          block_correlated_judgments, source_flip_judgments,
                          acc_majority, majority,
                          norm_ppf, _latent_rho_for, sigmoid, logit)

def hdr(t): print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)

# ---------- 通用：分块世界里的折叠聚合 ----------
def fold_aggregate(row, clusters):
    """clusters: 簇标签列表。每簇内多数成 1 票（平票 0.5），再簇间多数。"""
    cvotes = {}
    for i, c in enumerate(clusters):
        cvotes.setdefault(c, []).append(row[i])
    score = 0.0
    for c, vals in cvotes.items():
        top, _, tie = majority(vals)
        score += 0.5 if tie else top
    ncl = len(cvotes)
    return 1 if score > ncl/2 else (0 if score < ncl/2 else 0.5)

def acc_fold(mat, clusters):
    return mean(fold_aggregate(row, clusters) for row in mat)

# ================= E14 从投票记录检测相关并折叠 =================
class DSU:
    def __init__(self, n): self.p = list(range(n))
    def find(self, x):
        while self.p[x] != x: self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb: self.p[ra] = rb

def phi(x, y):
    n = len(x); mx, my = mean(x), mean(y)
    num = sum((a-mx)*(b-my) for a, b in zip(x, y))/n
    den = math.sqrt(mx*(1-mx)*my*(1-my)) + 1e-9
    return num/den

def detect_clusters(hist, theta=0.40):
    n = len(hist[0]); dsu = DSU(n)
    cols = [[row[i] for row in hist] for i in range(n)]
    for i in range(n):
        for j in range(i+1, n):
            if phi(cols[i], cols[j]) > theta:
                dsu.union(i, j)
    label = {}; out = []
    for i in range(n):
        r = dsu.find(i)
        if r not in label: label[r] = len(label)
        out.append(label[r])
    return out, len(label)

hdr("E14 独立性检测 + 相关折叠（大坏信源 12 人 p=0.48 vs 三个小好信源各 4 人 p=0.62，rho=0.85）")
SIZES = [12, 4, 4, 4]; PS = [0.48, 0.62, 0.62, 0.62]
rng = random.Random(1400)
hist, true_cl = block_correlated_judgments(rng, SIZES, PS, 0.85, 200)
det_cl, n_det = detect_clusters(hist)
print(f"  真实信源簇 = {len(SIZES)}，从 200 题投票记录盲检测出簇 = {n_det}")
rng = random.Random(1401)
ev, _ = block_correlated_judgments(rng, SIZES, PS, 0.85, 4000)
flat = acc_majority(ev)
orc = acc_fold(ev, true_cl)
det = acc_fold(ev, det_cl)
# 4 个真正独立、各自能力不同的信源
rng = random.Random(1402)
ind_correct = 0.0
for _ in range(4000):
    row = [1 if rng.random() < p else 0 for p in PS]
    top, _, tie = majority(row)
    ind_correct += 0.5 if tie else top
print(f"  平铺 24 人多数（12 人坏信源高一致、以数量压过好信源）= {flat:.3f}")
print(f"  按真实簇折叠（每个信源各 1 票，3 好压 1 坏）       = {orc:.3f}")
print(f"  按盲检测簇折叠（不告知真实分组）                    = {det:.3f}")
print(f"  对照：4 个真正独立的异质信源多数                    = {ind_correct/4000:.3f}")
print("  解读：高相关下'人多'只是同一信源的复读，平铺让大信源以数量绑架结果；")
print("        折叠后准确率回到独立信源水平，且簇结构仅凭历史投票记录即可盲检出")

# ================= E15 两级分组：否定性结果 + 组内冗余饱和 =================
hdr("E15 两级分组聚合（信源可靠度 0.70，个体以 0.25 翻转，4000 题）——预期'分层更鲁棒'")
print("  [15a] 固定 64 人，等大分组：两级 vs 平铺 vs G 个真独立信源上界")
print(f"  {'组数 G':>7}{'每组人数':>8}{'平铺多数':>10}{'两级聚合':>10}{'G独立信源上界':>15}")
for G in (1, 2, 4, 8, 16, 32):
    sizes = [64//G]*G
    rng = random.Random(1500+G)
    mat, cl = source_flip_judgments(rng, sizes, 0.70, 0.25, 4000)
    flat = acc_majority(mat)
    hier = acc_fold(mat, cl) if G > 1 else flat
    r2 = random.Random(1550+G)
    ub = acc_majority(independent_judgments(r2, G, 0.70, 4000)[0])
    print(f"  {G:>7}{64//G:>8}{flat:>10.3f}{hier:>10.3f}{ub:>15.3f}")

print("\n  [15b] 单个信源组：组内多数还原信源的质量 q 随组人数 m（边际个体仅 0.60）")
print(f"  {'组内人数 m':>10}{'组内多数正确率 q(m)':>20}")
for m in (1, 2, 4, 8, 16, 32):
    rng = random.Random(1580+m)
    mat, cl = source_flip_judgments(rng, [m], 0.70, 0.25, 4000)
    print(f"  {m:>10}{acc_majority(mat):>20.3f}")
print("  解读（否定性）：[15a] 等大分组下两级≈平铺≈独立信源上界，分层流程不创造独立性，")
print("        准确率只由信源数 G 决定；[15b] 每组约 8 人即可把 0.60 的个体还原到接近")
print("        信源上限 0.70，再加人不增分一个组。最优结构=每信源配 ~8 人、余者找新信源；")
print("        分组仅在 E14 那种'大小不等、大信源以数量绑架'时才改变结果——推翻'分层天然更鲁棒'")

# ================= E16 拜占庭鲁棒聚合的临界点 =================
def krum_1d(vals, f):
    k = len(vals) - f - 2
    best, bs = None, float("inf")
    for v in vals:
        d2 = sorted((v-w)**2 for w in vals if w != v)
        s = sum(d2[:max(k,1)])
        if s < bs: best, bs = v, s
    return best

hdr("E16 拜占庭聚合：f 比例恶意节点恒定输出 +10，N=25，好人 N(0,1)，400 世界")
print(f"  {'恶意比例 f':>10}{'mean':>9}{'median':>9}{'trim(f)':>9}{'Krum':>9}")
for f in (0.08, 0.16, 0.24, 0.32, 0.40, 0.48):
    errs = {k: [] for k in ("mean","median","trim","krum")}
    for s in range(400):
        rng = random.Random(1600+s)
        ngood, nbad = 25-round(f*25), round(f*25)
        vals = [gauss(rng) for _ in range(ngood)] + [10.0]*nbad
        errs["mean"].append(abs(mean(vals)))
        errs["median"].append(abs(median(vals)))
        errs["trim"].append(abs(trimmed_mean(vals, f)))
        errs["krum"].append(abs(krum_1d(vals, nbad)))
    print(f"  {f:>10.2f}{mean(errs['mean']):>9.2f}{mean(errs['median']):>9.2f}"
          f"{mean(errs['trim']):>9.2f}{mean(errs['krum']):>9.2f}")
print("  解读：mean 随 f 线性崩坏；trim 只在 f 不超过裁剪量时稳，一过界立刻崩；")
print("        median/Krum 在 f<0.5 全程稳定——鲁棒性来自聚合算子的崩溃点，而非检测恶意")

# ================= E17 人头的边际价值 =================
hdr("E17 加人的边际价值：独立 vs 相关 rho=0.3（p=0.55，4000 题）")
print(f"  {'人数 N':>8}{'独立世界':>11}{'相关世界':>11}{'相关等效独立人数':>17}")
for N in (1, 3, 5, 11, 25, 51, 101):
    r1 = random.Random(1700+N); m1,_ = independent_judgments(r1, N, 0.55, 4000)
    r2 = random.Random(1700+N); m2,_ = correlated_judgments(r2, N, 0.55, 0.3, 4000)
    neff = N/(1+(N-1)*0.3)
    print(f"  {N:>8}{acc_majority(m1):>11.3f}{acc_majority(m2):>11.3f}{neff:>17.1f}")
print("  解读：独立世界加人持续逼近 1；相关世界早早进入平台期。预算应花在'买独立信源'")
print("        （降 rho、增加检测到的簇数），而不是给同一信源多买几张嘴")

# ================= E18 漂移下的权重：近因是药还是毒 =================
def est_full(h): return mean(h) if h else 0.5
def est_slide(h, w=20): return mean(h[-w:]) if h else 0.5
def est_decay(h, hl=15):
    if not h: return 0.5
    ws = [0.5**((len(h)-1-i)/hl) for i in range(len(h))]; z = sum(ws)
    return sum(x*w for x, w in zip(h, ws))/z

def scenario_probs(sc, t):
    if sc == "static": return 0.70, 0.55
    if sc == "swap":   return (0.70, 0.50) if t < 50 else (0.50, 0.70)
    return (0.70, 0.55)                      # slump：能力不变

def run_e18(sc, policy, reps=400, T=120):
    acc = []
    for rep in range(reps):
        rng = random.Random(1800+rep); hA, hB = [], []
        drift_flag = False; correct = 0
        for t in range(T):
            pA, pB = scenario_probs(sc, t)
            # slump：A 在 40-60 题遭遇坏运气（数据形态与漂移无法区分）
            genA = 0.45 if (sc == "slump" and 40 <= t < 60) else pA
            a = 1 if rng.random() < genA else 0
            b = 1 if rng.random() < pB else 0
            if policy == "full":
                eA, eB = est_full(hA), est_full(hB)
            elif policy == "slide":
                eA, eB = est_slide(hA), est_slide(hB)
            elif policy == "decay":
                eA, eB = est_decay(hA), est_decay(hB)
            else:  # anchored：每 10 题用独立金标题仲裁 A 是否真漂移
                if t >= 45 and t % 10 == 5:
                    anchor = sum(1 for _ in range(20) if rng.random() < pA)/20
                    se = math.sqrt(0.7*0.3/20)
                    if anchor < 0.70 - 1.96*se: drift_flag = True
                if drift_flag: eA, eB = est_slide(hA), est_slide(hB)
                else: eA, eB = est_full(hA), est_full(hB)
            pred = a if eA >= eB else b
            correct += pred
            hA.append(a); hB.append(b)
        acc.append(correct/T)
    return mean(acc)

hdr("E18 概念漂移下的专家权重策略（2 专家，120 题 × 400 世界，选估计更强者）")
print(f"  {'环境':<16}{'全历史':>9}{'滑窗20':>9}{'指数衰减':>9}{'锚定仲裁':>9}")
for sc, name in (("static","静态(无漂移)"), ("swap","第50题能力对调"),
                 ("slump","假漂移(运气低谷)")):
    row = [run_e18(sc, p) for p in ("full","slide","decay","anchored")]
    print(f"  {name:<15}" + "".join(f"{v:>9.3f}" for v in row))
print("  解读：静态时全历史最稳、近因策略反而引入噪声；真漂移时近因快速跟上、全历史被锁死；")
print("        运气低谷时近因策略误切换而受损——'真漂移'与'坏运气'在序列上同形，")
print("        只有永不更新的锚定金标题能仲裁：该快时快、该稳时稳")
