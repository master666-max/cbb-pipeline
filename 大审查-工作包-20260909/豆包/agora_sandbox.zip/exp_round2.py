"""exp_round2.py — 第二轮：依赖、级联与极化（E4-E6）"""
import random
from agora_common import (mean, median, std, majority, gauss,
                          net_ring, net_ws, net_full, net_ba, degroot)

def hdr(t): print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)

# ================= E4 顺序信息级联（BHW） =================
def cascade_trial(rng, N, q, stubborn=()):
    """返回 (是否发生级联, 级联方向是否错, 被忽略信号比例, 最终多数是否对, T)"""
    T = rng.randint(0, 1)
    d = 0                       # 已被公开行动揭示的净信号
    cascade = None              # None / 0 / 1
    actions = []
    ignored = 0
    for i in range(N):
        sig = 1 if (rng.random() < q) == (T == 1) else -1   # +1 指向状态1
        if i in stubborn:
            a = 1 if sig == 1 else 0
            d += sig
            if abs(d) < 2:
                cascade = None              # 倔强人的真实信号可解除级联
            actions.append(a); ignored += 0
            continue
        if cascade is not None:
            a = cascade
            actions.append(a); ignored += int((1 if a == 1 else -1) != sig)
        else:
            tot = d + sig
            if tot >= 2:
                a, cascade = 1, 1
            elif tot <= -2:
                a, cascade = 0, 0
            else:
                a = 1 if sig == 1 else 0
                d += sig
            actions.append(a); ignored += int((1 if a == 1 else -1) != sig)
    top, _, tie = majority(actions)
    final_correct = 0.5 if tie else int(top == T)
    return (cascade is not None, int(cascade != T) if cascade is not None else None,
            ignored / N, final_correct, T)

def run_cascade(label, stubborn=(), trials=20000, N=20, q=0.6):
    rng = random.Random(404)
    n_casc = n_wrong = ignored_sum = correct_sum = 0
    for _ in range(trials):
        c, wrong, ign, fc, T = cascade_trial(rng, N, q, stubborn)
        n_casc += int(c)
        if c: n_wrong += wrong
        ignored_sum += ign; correct_sum += fc
    print(f"  {label:<28} 级联率 {n_casc/trials:.3f} | 错误级联占比 "
          f"{n_wrong/max(n_casc,1):.3f} | 信号被忽略 {ignored_sum/trials:.3f} "
          f"| 终局正确率 {correct_sum/trials:.3f}")

hdr("E4 顺序信息级联（N=20, 信号可靠度 q=0.6, 2 万次）")
# 同时独立投票基线
rng = random.Random(405)
sim_correct = []
for _ in range(20000):
    T = rng.randint(0, 1)
    votes = [1 if ((rng.random() < 0.6) == (T == 1)) else 0 for _ in range(20)]
    top, _, tie = majority(votes)
    sim_correct.append(0.5 if tie else int(top == T))
print(f"  {'同时独立投票（基线）':<26} 终局正确率 {mean(sim_correct):.3f}")
run_cascade("顺序决策、全部理性")
run_cascade("顺序决策 + 2 个倔强人", stubborn=(5, 11))
run_cascade("顺序决策 + 4 个倔强人", stubborn=(3, 7, 11, 15))
print("  解读：顺序公开决策会自发锁定，且约 1/4~1/3 的级联锁向错误方向；")
print("        少量坚持私有信息的人能显著打断错误级联")

# ================= E5 拓扑对共识的影响 =================
hdr("E5 网络拓扑 × DeGroot 反复平均（n=40, 30% 人带 +20 偏差, 200 世界）")
print(f"  {'拓扑':<12}{'收敛轮数':>10}{'共识偏差(对真值)':>16}{'最终群体内std':>15}")
for name, fn in (("环形", lambda s: net_ring(40)),
                 ("小世界", lambda s: net_ws(40, seed=s)),
                 ("全连接", lambda s: net_full(40)),
                 ("无标度", lambda s: net_ba(40, seed=s))):
    convs, biases, spreads = [], [], []
    for s in range(200):
        rng = random.Random(500+s)
        adj = fn(s)
        x0 = [(20 + 3*gauss(rng)) if rng.random() < 0.3 else (3*gauss(rng)) for _ in range(40)]
        xf, r = degroot(adj, x0)
        convs.append(r); biases.append(abs(mean(xf))); spreads.append(std(xf))
    print(f"  {name:<12}{mean(convs):>10.1f}{mean(biases):>16.2f}{mean(spreads):>15.3f}")
print("  解读：反复平均必然收敛到单一共识（std→0），拓扑只决定速度与共识落点；")
print("        全连接最快，但也最快地把偏差平均进共识——速度不等于正确")

# ================= E6 有界信任与极化 =================
def hk_dynamics(x0, tau, maxit=300, tol=1e-4):
    """Hegselmann-Krause 有界信任：只和意见差 < tau 的人平均"""
    x = list(x0)
    for _ in range(maxit):
        nx = []
        for i in range(len(x)):
            peers = [j for j in range(len(x)) if abs(x[j]-x[i]) < tau]
            nx.append(sum(x[j] for j in peers)/len(peers))
        if max(abs(a-b) for a, b in zip(nx, x)) < tol:
            x = nx; break
        x = nx
    clusters = 0; used = [False]*len(x)
    sx = sorted(x)
    for i, v in enumerate(sx):
        if not used[i]:
            clusters += 1
            for j in range(i, len(sx)):
                if abs(sx[j]-v) < 1.0: used[j] = True
                else: break
    return x, clusters

hdr("E6 讨论是否导致极化：无界平均 vs 有界信任（两群初始意见 0 / 30，各 20 人）")
print(f"  {'机制':<24}{'最终簇数':>8}{'两极间距':>10}{'接近真值0的人口':>15}{'群体内std':>11}")
for label, tau in (("无界信任(反复平均)", None), ("有界信任 tau=50", 50),
                   ("有界信任 tau=12", 12), ("有界信任 tau=6", 6)):
    cs, gaps, near, sps = [], [], [], []
    for s in range(200):
        rng = random.Random(600+s)
        x0 = [gauss(rng) for _ in range(20)] + [30 + gauss(rng) for _ in range(20)]
        if tau is None:
            xf, _ = degroot(net_full(40), x0); cl = 1
        else:
            xf, cl = hk_dynamics(x0, tau)
        cs.append(cl); gaps.append(max(xf)-min(xf))
        near.append(sum(1 for v in xf if abs(v) < 3)/len(xf)); sps.append(std(xf))
    print(f"  {label:<23}{mean(cs):>8.1f}{mean(gaps):>10.1f}"
          f"{mean(near)*100:>14.1f}%{mean(sps):>11.2f}")

print("\n  连续意见谱（40 人均匀分布在 0~30）：信任半径越小，共识碎成越多簇")
print(f"  {'信任半径 tau':<18}{'最终簇数':>9}{'群体内std':>11}")
for tau in (50, 20, 10, 5, 3):
    cs, sps = [], []
    for s in range(200):
        rng = random.Random(650+s)
        x0 = [rng.uniform(0, 30) for _ in range(40)]
        xf, cl = hk_dynamics(x0, tau)
        cs.append(cl); sps.append(std(xf))
    print(f"  tau={tau:<13}{mean(cs):>9.1f}{mean(sps):>11.2f}")
print("  解读：无界平均把原本正确的一半人也带到 15（接近真值者从 50%→0%）；")
print("        有界信任保住了正确的一半，但让另一半锁死在 30——'达成共识'本身不是好事，")
print("        极化的机制是选择性倾听（只听相近意见），不是平均动作本身")
