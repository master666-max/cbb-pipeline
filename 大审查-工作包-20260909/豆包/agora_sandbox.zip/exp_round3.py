"""exp_round3.py — 第三轮：谁该被信任（E7-E9）：加权专家、信誉漂白、预测市场"""
import math, random
from agora_common import mean, median, sigmoid, logit, gauss

def hdr(t): print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)

# ================= E7 按历史准确率加权：何时是过拟合 =================
def expert_world(kind, seed):
    rng = random.Random(seed)
    if kind == "hetero":                       # 能力差异大
        return [0.45 + 0.35 * rng.random() for _ in range(11)]
    return [0.53 + 0.06 * rng.random() for _ in range(11)]   # 能力几乎相同

def vote_aggregate(votes, weights):
    s = sum(w * (1 if v else -1) for v, w in zip(votes, weights))
    return 1 if s > 0 else (0 if s < 0 else 0.5)

def e7(kind):
    pj = expert_world(kind, seed=700)
    HOLDOUT = 200; REPS = 400
    print(f"\n  世界={kind}，11 位专家，真实能力区间 [{min(pj):.2f},{max(pj):.2f}]，均值 {mean(pj):.3f}")
    print(f"  {'历史题数 m':>10}{'等权多数':>12}{'按估计加权':>12}{'Oracle真能力':>14}")
    for m in (4, 16, 64, 100000):
        eq_h, hat_h, orc_h = [], [], []
        for rep in range(REPS):
            rng = random.Random(701 + rep)
            if m >= 100000:
                phat = list(pj)
            else:
                phat = [(sum(1 for _ in range(m) if rng.random() < p) + 0.5) / (m + 1) for p in pj]
            w_hat = [logit(x) for x in phat]
            w_orc = [logit(p) for p in pj]
            eq_c = hat_c = orc_c = 0
            for _ in range(HOLDOUT):
                votes = [rng.random() < p for p in pj]    # 真值固定为 1
                eq_c += vote_aggregate(votes, [1]*11)
                hat_c += vote_aggregate(votes, w_hat)
                orc_c += vote_aggregate(votes, w_orc)
            eq_h.append(eq_c/HOLDOUT); hat_h.append(hat_c/HOLDOUT); orc_h.append(orc_c/HOLDOUT)
        tag = "∞" if m >= 100000 else str(m)
        print(f"  {tag:>10}{mean(eq_h):>12.3f}{mean(hat_h):>12.3f}{mean(orc_h):>14.3f}")

hdr("E7 按历史准确率加权 vs 等权（留出 200 题 × 400 次历史重估）")
e7("hetero")
e7("homo")
print("  解读：能力差异大时，加权需要足够历史才追上等权并最终反超；")
print("        历史只有 4 题时权重是噪声，加权反而更差；能力同质时加权永远没有红利")

# ================= E8 信誉漂白 whitewashing =================
def whitewash(init_n, init_sum, theta=0.7, steps=300, seed=1):
    """坏节点：信誉>=theta 就有一半概率作恶(反馈0)/一半继续伪装(1)；
    低于 theta 就刻意养好；若跌破则弃号换新（虚拟历史 init_n/init_sum）。"""
    rng = random.Random(seed)
    n, s = init_n, init_sum
    accepted = 0; n_reset = 0
    for _ in range(steps):
        rep = s / n
        if rep < theta:                          # 养号：必须表现好
            fb = 1
        else:
            accepted += 1
            fb = 1 if rng.random() < 0.5 else 0  # 被接受后一半概率作恶
        n += 1; s += fb
        if s / n < theta and rep >= theta:       # 一次作恶导致跌破 -> 换号
            n, s = init_n, init_sum; n_reset += 1
    return accepted / steps, n_reset

def newcomer_steps(init_n, init_sum, theta=0.7, good_rate=0.9, reps=3000):
    """真新好人（好评率 0.9）达到可信阈值所需交互数"""
    rng = random.Random(810); out = []
    for _ in range(reps):
        n, s = init_n, init_sum; k = 0
        while s / n < theta and k < 200:
            s += 1 if rng.random() < good_rate else 0; n += 1; k += 1
        out.append(k)
    return mean(out)

hdr("E8 信誉漂白：换号成本 vs 新人摩擦（阈值 0.7，300 步/策略）")
policies = (("新号中性 0.50", 2, 1.0), ("新号有罪推定 0.00", 4, 0.0),
            ("新号=全局均分 0.88", 4, 3.52))
print(f"  {'入场策略':<22}{'坏人被接受率':>13}{'坏人换号次数':>13}{'好新人达阈值步数':>17}")
for name, ni, si in policies:
    acc, nr = whitewash(ni, si)
    ns = newcomer_steps(ni, si)
    print(f"  {name:<21}{acc:>13.3f}{nr:>13d}{ns:>17.2f}")
print("  解读：入场分越低，漂白越难但新人越受拖累；'新号=全局均分'对好人友好却")
print("        几乎免费放行坏人——没有既防漂白又不伤新人的免费入场策略")

# ================= E9 LMSR 预测市场 =================
def lmsr_price(qdiff, b):
    return sigmoid(qdiff / b)

def lmsr_push_cost(b, p_target):
    """从价 0.5 一把推到 p_target 的成本 C 差"""
    d = b * logit(p_target)
    return b * math.log(1 + math.exp(d / b)) - b * math.log(2)

def market_run(n_rational, b=10.0, manip_to=None, step=0.5, seed=1,
               true_logit=0.6, sigma=0.7):
    rng = random.Random(seed)
    qdiff = 0.0
    beliefs = []
    if manip_to is not None:
        qdiff = b * logit(manip_to)             # 操纵者首单把价推到 manip_to
    for i in range(n_rational):
        bel = sigmoid(true_logit + sigma * gauss(rng))
        beliefs.append(bel)
        target = b * logit(bel)
        qdiff += step * (target - qdiff)        # 向自己信念部分调整
    return lmsr_price(qdiff, b), mean(beliefs) if beliefs else 0.5

hdr("E9 LMSR 预测市场：聚合精度、操纵恢复与操纵成本（真值信念≈0.646）")
print("  [9a] 无操纵：市场终价 vs 群体平均信念")
for n in (3, 8, 20):
    ps, bs = [], []
    for s in range(500):
        p, bavg = market_run(n, seed=s); ps.append(p); bs.append(bavg)
    print(f"  N={n:<3} 市场终价均值 {mean(ps):.3f} | 平均信念 {mean(bs):.3f} "
          f"| 市场Brier {mean((x-1)**2 for x in ps):.3f} | 平均信念Brier {mean((x-1)**2 for x in bs):.3f}")

print("\n  [9b] 操纵者先把价推到 0.90，之后理性人数 vs 恢复程度（b=10）")
print(f"  {'理性人数':>8}{'市场终价':>10}{'残留操纵偏差':>14}")
for n in (0, 1, 3, 8, 20):
    ps = [market_run(n, manip_to=0.9, seed=900+s)[0] for s in range(500)]
    base = [market_run(n, seed=900+s)[0] for s in range(500)]
    print(f"  {n:>8}{mean(ps):>10.3f}{mean(ps)-mean(base):>14.3f}")

print("\n  [9c] 把价从 0.5 推到 0.9 的操纵成本（以及做市商最大补贴 b·log2）")
print(f"  {'b':>6}{'推到0.9成本':>13}{'做市商最大补贴':>15}")
for b in (5, 10, 20, 40):
    print(f"  {b:>6}{lmsr_push_cost(b,0.9):>13.2f}{b*math.log(2):>15.2f}")
print("  解读：市场能聚合分散信念，且一次性操纵会被后续理性交易逐步拉回；")
print("        但'拉回'依赖足够多的后续理性人，而 b 只决定操纵要花多少钱——安全是定价的")
