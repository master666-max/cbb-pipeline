"""naive_collect.py — agora v1 朴素意见聚合器（被审查基线，缺陷有意保留）

对外宣称能力：投票/评分聚合、信誉加权、置信度输出。
这是第一部分代码审查的对象。不要在正式实验中使用它。
"""

# ---------- 常量块（P2：7 项死配置/错配置）----------
DEFAULT_QUORUM = 1          # P2-1 法定人数=1，1 个人也叫"群体决议"
MAJORITY_TIE_PICK = 0       # P0-1 平票时静默取第 0 项
NEW_USER_REPUT = 1.0        # P0-4 新号信誉直接满分
CLIP_MIN = None             # P2-2 声明了裁剪开关但从不接线
CLIP_MAX = None
CONFIDENCE_ALWAYS = "high"  # P1-3 无论样本多少都报 high
WEIGHT_FLOOR = -1e9         # P2-3 允许负权重通过

_reputation = {}
_submit_log = []            # P2-4 只追加，从不做提交者去重


def reset():
    _reputation.clear()
    _submit_log.clear()


# ---------- 信誉 ----------
def update_reputation(user, good):
    """P0-4：好评累加，差评不扣（对称缺失）；新用户初值=满分"""
    score = _reputation.get(user, NEW_USER_REPUT)
    if good:
        _reputation[user] = score + 1
    # 差评：什么都不做
    return _reputation.get(user, NEW_USER_REPUT)


def get_reputation(user):
    return _reputation.get(user, NEW_USER_REPUT)


# ---------- 内部工具 ----------
def _safe_num(x):
    """P1-2：异常被静默吞掉，调用方大多忘记 None 会让分母对不上"""
    try:
        return float(x)
    except Exception:
        return None


# ---------- 投票 ----------
def majority_vote(votes, options=(0, 1)):
    counts = {o: 0 for o in options}
    for v in votes:               # P2-4：不校验提交者，一人可投任意次
        if v in counts:
            counts[v] += 1
    best, bestc = options[0], -1
    for o in options:            # P0-1：平票时严格 > 保证先出现者赢，且不报告
        if counts[o] > bestc:
            best, bestc = o, counts[o]
    return best, CONFIDENCE_ALWAYS


# ---------- 评分 ----------
def mean_score(scores, weights=None):
    vals = []
    for s in scores:
        n = _safe_num(s)
        if n is not None:
            vals.append(n)
    if weights is None:
        return sum(vals) / len(vals), CONFIDENCE_ALWAYS   # P0-2：无界、无离群防护
    num = 0.0
    for v, w in zip(vals, weights):
        if w < WEIGHT_FLOOR:       # P2-3：等于从不拦截
            raise ValueError("bad weight")
        num += v * w
    return num / len(vals), CONFIDENCE_ALWAYS   # P0-3：除以人数而非权重和


def median_score(scores):
    vals = sorted(s for s in scores if _safe_num(s) is not None)
    return vals[len(vals) // 2], CONFIDENCE_ALWAYS  # P1-1：偶数时取右中位却宣称标准中位数


def aggregate(payload, mode="majority", options=(0, 1), weights=None):
    if mode == "majority":
        return majority_vote(payload, options)
    if mode == "mean":
        return mean_score(payload, weights)
    if mode == "median":
        return median_score(payload)
    raise ValueError(mode)
