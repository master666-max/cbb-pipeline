"""exp_round4.py — 第四轮：操纵与防御（E10-E13）"""
import math, random
from agora_common import (mean, median, std, gauss, net_full, net_ba, degroot)

def hdr(t): print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)

# ================= E10 Sybil：多少马甲能翻转 =================
hdr("E10 Sybil 攻击：翻转 55:45 的真实民意所需成本（100 真实选民）")
A, B = 55, 45                     # 真实票：A 正确方 55，B 45
print(f"  真实票：A={A}, B={B}，攻击者为 B 方注水")
def min_to_flip_equal():
    s = 0
    while B + s <= A: s += 1
    return s
s_eq = min_to_flip_equal()
print(f"\n  [等权一人一票] 翻转需 {s_eq} 个马甲（攻击者成本 = {s_eq} 个身份）")

# 信誉加权：老号权重 1，新号权重 w0；总加权票 A=55*1，B=45*1 + s*w0
for name, w0 in (("新号权重 0.5（中性入场）", 0.5), ("新号权重 0（有罪推定）", 0.0),
                 ("新号权重 0.88（=全局均分）", 0.88)):
    s = 0
    while 45 + s * w0 <= 55:
        s += 1
        if s > 100000: break
    print(f"  [信誉加权·{name}] 翻转需 {s if s<=100000 else '∞（永远无法翻转）'} 个马甲")

# QV：每个好人预算 1（买 1 票），攻击者总预算 X 可得 sqrt(X) 票
need = A - B + 1
print(f"\n  [二次方投票 QV] 好人侧 55 人各花预算 1 买 1 票；攻击者买 k 票成本 k²")
print(f"  要使 B 方净胜需 k≥{need} 票，攻击者总预算 = {need**2}（= {need**2} 个普通人预算）")
print(f"  等权下同等目标只需 {s_eq} 个身份；QV 把攻击成本放大 {need**2/s_eq:.1f} 倍")
print("  解读：一人一票把'造身份'等同于'造民意'；给新身份降权或让票数凸成本化，")
print("        攻击成本从线性抬到无穷/平方级——抗 Sybil 靠身份价格，不靠事后检测")

# ================= E11 洗脑：顽固节点与 hub 控制 =================
def brainwash(net_fn, f, mode="random", defense=mean, rounds=None, worlds=120, n=40, bias=20.0):
    """rounds=None 跑到收敛；否则固定轮数（tol=-1 不提前停）。返回正常节点平均 |偏差|"""
    biases = []
    for s in range(worlds):
        rng = random.Random(1100+s); adj = net_fn(s)
        x0 = [3*gauss(rng) for _ in range(n)]
        nbad = round(f*n)
        if mode == "hub":
            deg = {i: len(adj[i]) for i in range(n)}
            bad = sorted(range(n), key=lambda i: -deg[i])[:nbad]
        else:
            bad = rng.sample(range(n), nbad)
        stub = {i: bias for i in bad}
        xf, _ = degroot(adj, x0, stubborn=stub, agg=defense,
                        maxit=rounds or 300, tol=-1 if rounds else 1e-4)
        good = [v for i, v in enumerate(xf) if i not in stub]
        biases.append(abs(mean(good)))
    return mean(biases)

def assimilate_speed(net_fn, f, mode="random", n=40, bias=20.0, worlds=60):
    rs = []
    for s in range(worlds):
        rng = random.Random(1150+s); adj = net_fn(s)
        x0 = [3*gauss(rng) for _ in range(n)]
        nbad = round(f*n)
        if mode == "hub":
            deg = {i: len(adj[i]) for i in range(n)}
            bad = set(sorted(range(n), key=lambda i: -deg[i])[:nbad])
        else:
            bad = set(rng.sample(range(n), nbad))
        x = list(x0); stub = {i: bias for i in bad}
        for r in range(1, 501):
            nx = list(x)
            for i in range(n):
                if i in stub: nx[i] = bias
                else: nx[i] = mean([x[j] for j in adj[i] | {i}])
            x = nx
            if all(abs(bias-v) < 0.5 for i, v in enumerate(x) if i not in stub):
                rs.append(r); break
    return mean(rs)

hdr("E11 洗脑：持续广播节点的影响（广播值 20，正常人初始≈0）")
print("  [11a] 短期固定 8 轮：f 与是否控制 hub 的差异")
print(f"  {'f 被控比例':>10}{'全连接·均值':>13}{'无标度·随机':>13}{'无标度·控hub':>14}{'全连接·中位防御':>17}")
for f in (0.1, 0.2, 0.3, 0.4):
    a = brainwash(lambda s: net_full(40), f, "random", mean, rounds=8)
    b = brainwash(lambda s: net_ba(40, seed=s), f, "random", mean, rounds=8)
    c = brainwash(lambda s: net_ba(40, seed=s), f, "hub", mean, rounds=8)
    d = brainwash(lambda s: net_full(40), f, "random", median, rounds=8)
    print(f"  {f:>10.1f}{a:>13.2f}{b:>13.2f}{c:>14.2f}{d:>17.2f}")
print("\n  [11b] 长期：均值聚合下正常节点被完全同化(偏差→20)所需轮数")
print(f"  {'f':>6}{'全连接':>10}{'无标度随机':>12}{'无标度控hub':>13}")
for f in (0.1, 0.2, 0.3):
    a = assimilate_speed(lambda s: net_full(40), f)
    b = assimilate_speed(lambda s: net_ba(40, seed=s), f, "random")
    c = assimilate_speed(lambda s: net_ba(40, seed=s), f, "hub")
    print(f"  {f:>6.1f}{a:>10.1f}{b:>12.1f}{c:>13.1f}")
dlong = brainwash(lambda s: net_full(40), 0.1, "random", mean)
mlong = brainwash(lambda s: net_full(40), 0.4, "random", median)
print(f"\n  [11c] 跑满 300 轮：均值聚合即使只有 10% 顽固节点，正常节点偏差也={dlong:.2f}（被完全同化）；")
print(f"        中位数防御在 40% 顽固节点下偏差仍={mlong:.2f}")
print("  解读：持续广播是'时间武器'——数量只决定同化速度，强连通网络里一个永不移动的")
print("        节点长期赢者通吃；控 hub 只是加速。中位数聚合让 f<0.5 的广播无法收敛过去")

# ================= E12 议程设置与投票规则 =================
hdr("E12 同一批偏好，胜者由规则/议程决定（Condorcet 循环）")
# 35% A>B>C ; 33% B>C>A ; 32% C>A>B
groups = [(0.35, ["A","B","C"]), (0.33, ["B","C","A"]), (0.32, ["C","A","B"])]
def pairwise(x, y):
    vx = sum(w for w, r in groups if r.index(x) < r.index(y))
    return x if vx > 0.5 else y
print("  两两对决：A vs B ->", pairwise("A","B"), "| B vs C ->", pairwise("B","C"),
      "| C vs A ->", pairwise("C","A"), "（循环，无孔多塞胜者）")
def agenda(first, second, third):
    w1 = pairwise(first, second); return pairwise(w1, third)
print("\n  顺序议程（先两人对决，胜者再对第三人）：")
for order in (("A","B","C"),("B","A","C"),("A","C","B"),("C","A","B"),
              ("B","C","A"),("C","B","A")):
    print(f"    议程 {order} -> 最终胜者 {agenda(*order)}")
# Plurality / Borda / Approval
plu = {c: sum(w for w, r in groups if r[0] == c) for c in "ABC"}
borda = {c: sum(w*(2-r.index(c)) for w, r in groups) for c in "ABC"}
appr = {c: sum(w for w, r in groups if r.index(c) <= 1) for c in "ABC"}
print(f"\n  多数票(plurality): {plu} -> 胜者 {max(plu,key=plu.get)}")
print(f"  博达计票(Borda)  : { {c:round(v,2) for c,v in borda.items()} } -> 胜者 {max(borda,key=borda.get)}")
print(f"  批准制(批前两名) : {appr} -> 胜者 {max(appr,key=appr.get)}")
print("  解读：6 种议程能让 3 个候选人分别胜出；没有'中立计票'，规则本身携带政治")

# ================= E13 多样性 vs 能力（Page 定理 + 边界）=================
def team_estimate(rng, n, sigma, common_bias, rho):
    g = gauss(rng)
    return [common_bias + math.sqrt(rho)*g + math.sqrt(1-rho)*sigma*gauss(rng) for _ in range(n)]

hdr("E13 多样性 vs 能力：Page 多样性预测定理及其失效边界（真值=0，1000 世界）")
# 数值验证 Page 恒等式：群体误差 = 平均个体误差 - 多样性
rng = random.Random(1300); ce=[]; ai=[]; dv=[]
for _ in range(1000):
    pred = team_estimate(rng, 10, 4.0, 0.0, 0.0)
    crowd = mean(pred)
    ce.append(crowd**2); ai.append(mean((p)**2 for p in pred))
    dv.append(mean((p-crowd)**2 for p in pred))
print(f"  Page 恒等式校验：群体MSE {mean(ce):.3f} = 平均个体MSE {mean(ai):.3f} - 多样性 {mean(dv):.3f} "
      f"= {mean(ai)-mean(dv):.3f}")

print("\n  专家队（σ=3, 共同偏差 +2, 同质 ρ=0.7）vs 多样队（σ 变化, 无共同偏差, 独立）")
print(f"  {'多样队 sigma':>12}{'专家队MSE':>12}{'多样队MSE':>12}{'谁赢':>10}")
for sd in (3, 4, 5, 6, 7, 9):
    exp_m, div_m = [], []
    for s in range(1000):
        r1 = random.Random(1310+s); r2 = random.Random(1320+s)
        exp_m.append(mean(team_estimate(r1, 10, 3.0, 2.0, 0.7))**2)
        div_m.append(mean(team_estimate(r2, 10, sd, 0.0, 0.0))**2)
    win = "多样队" if mean(div_m) < mean(exp_m) else "专家队"
    print(f"  {sd:>12}{mean(exp_m):>12.3f}{mean(div_m):>12.3f}{win:>10}")
print("  解读：个体噪声适中时，'无偏+多样'能击败'更强但同向偏差'的专家；")
print("        但噪声超过交叉点后多样性救不回来——多样性红利以个体不能太差为前提")
