"""baseline_review.py — 对 naive_collect 的定向缺陷探针（第一部分用，全部实测）"""
import math
import random
import naive_collect as nc

def line(t=""): print(t)

line("="*64)
line("基线缺陷探针 · 每个 P0/P1 附复现与实测输出")
line("="*64)

# P0-1 平票由选项排列顺序决定
line("\n[P0-1] 平票静默取边，且结果取决于选项排列顺序")
votes = [0, 0, 1, 1]
r1 = nc.majority_vote(votes, options=(0, 1))
r2 = nc.majority_vote(votes, options=(1, 0))
line(f"  同一批票 {votes}")
line(f"  options=(0,1) -> {r1[0]} 置信度={r1[1]}")
line(f"  options=(1,0) -> {r2[0]} 置信度={r2[1]}")
line(f"  -> 同一民意、调换选项声明顺序即翻转: {r1[0] != r2[0]}；平票未被标记: 是")

# P0-2 单个无界离群值拖走均值
line("\n[P0-2] 均值无界：1 个离群值对抗 10 个正常评分")
rng = random.Random(7)
normal = [50 + rng.gauss(0, 1.0) for _ in range(10)]
clean, _ = nc.mean_score(normal)
attacked, _ = nc.mean_score(normal + [9999.0])
line(f"  10 人正常评分均值 = {clean:.2f}（真值 50）")
line(f"  加入 1 个 9999 后 = {attacked:.2f}，被拖高 {attacked-clean:.1f} 分")

# P0-3 缺失项导致权重与人错位（权重按原始位置对齐，丢弃后错配到别人头上）
line("\n[P0-3] 1 人缺评被静默丢弃，非等权下权重错配到他人头上")
scores = [40.0, "N/A", 60.0, 80.0]          # 第 2 人缺评
w = [1, 2, 3, 4]                            # 权重按 4 人登记
out, _ = nc.mean_score(scores, weights=w)
correct = (40*1 + 60*3 + 80*4) / (1+3+4)
line(f"  权重 {w}，第 2 人缺评；正确加权均值 = {correct:.2f}")
line(f"  聚合器输出 = {out:.2f}（权重 [1,3,4] 被错配成 [1,2,3]，且除以 3），偏差 {out-correct:+.2f}")

# P0-4 信誉：新号=满分，差评不扣
line("\n[P0-4] 信誉系统：新号满分，差评不扣")
nc.reset()
nc.update_reputation("old", True)
for _ in range(100):
    nc.update_reputation("old", True)
line(f"  100 次好评老号信誉 = {nc.get_reputation('old'):.1f}")
line(f"  刚注册新号信誉     = {nc.get_reputation('sybil_0001'):.1f}（与老号同权）")
for _ in range(50):
    nc.update_reputation("bad", False)
line(f"  连续 50 次差评账号 = {nc.get_reputation('bad'):.1f}（差评完全不扣分）")

# P1-1 偶数中位数取右中位
line("\n[P1-1] 偶数样本中位数实现错误")
vals = [1.0, 2.0, 3.0, 4.0]
got, _ = nc.median_score(vals)
line(f"  数据 {vals}，标准中位数=2.5，聚合器输出={got}")

# P1-2 + P1-3 异常吞掉 + 置信度恒 high
line("\n[P1-2/P1-3] 非法输入静默丢弃，参与人数缩水，置信度仍报 high")
out, conf = nc.mean_score([1, 2, "炸了", None, {}, 3])
line(f"  6 项提交、3 项非法被吞，输出={out:.2f}（只按 3 人算），置信度={conf}")

# P2-3 负权重
line("\n[P2-3] 负权重通过校验，可反向操纵加权均值")
out, _ = nc.mean_score([10.0, 10.0, 10.0], weights=[1.0, 1.0, -3.0])
line(f"  三个 10 分、权重 [1,1,-3] -> {out:.2f}（数学上被拉成负数，校验放行）")

# P2-4 一人多投
line("\n[P2-4] 无提交者去重：一个账号刷 100 票")
nc.reset()
honest = [1]*60 + [0]*40                 # 真实民意 60:40
r_h, _ = nc.majority_vote(honest)
brigaded = honest + [0]*100             # 同一攻击者重复提交 100 次
r_b, _ = nc.majority_vote(brigaded)
line(f"  真实 60:40 -> 胜者 {r_h}；攻击者自投 100 次后 -> 胜者 {r_b}")

# NaN 传播
line("\n[P2-5] NaN 比较恒 False，穿过所有校验污染结果")
nan = float("nan")
out, conf = nc.mean_score([50.0, 50.0, nan])
line(f"  mean([50,50,nan]) = {out}；isnan={math.isnan(out)}；置信度仍={conf}")

line("\n" + "="*64)
line("汇总：P0×4 / P1×3（P1-2、P1-3 合并计）/ P2×4，共 11 个实测缺陷")
line("="*64)
